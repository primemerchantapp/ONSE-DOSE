"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BarChart2, CreditCard, Users, LayoutDashboard, Settings, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

interface DashboardSidebarProps {
  isOpen: boolean
  onOpenChange: (open: boolean) => void
  className?: string
  style?: React.CSSProperties
}

export function DashboardSidebar({ isOpen, onOpenChange, className, style }: DashboardSidebarProps) {
  const pathname = usePathname()

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "User Management",
      href: "/dashboard/users",
      icon: Users,
    },
    {
      title: "Financials",
      href: "/dashboard/financials",
      icon: CreditCard,
    },
    {
      title: "Statistics",
      href: "/dashboard/statistics",
      icon: BarChart2,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ]

  return (
    <aside className={cn("pb-12", className)} style={style}>
      <div className="px-6 py-4">
        <Link href="/dashboard" className="flex items-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-6 w-6 text-primary"
          >
            <path d="M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41l-7.59-7.59a2.41 2.41 0 0 0-3.41 0Z" />
          </svg>
          <span className="font-bold">ONSE VIP</span>
        </Link>
      </div>

      <ScrollArea className="h-[calc(100vh-10rem)]">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-xs font-semibold uppercase tracking-tight text-muted-foreground">Navigation</h2>
          <div className="space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={(e) => {
                  // If we're on mobile, close the sidebar when navigating
                  if (window.innerWidth < 1024) {
                    onOpenChange(false)
                  }
                }}
              >
                <Button
                  variant={pathname === item.href ? "secondary" : "ghost"}
                  size="sm"
                  className={cn(
                    "w-full justify-start",
                    pathname === item.href ? "bg-secondary text-secondary-foreground" : "hover:bg-secondary/50",
                  )}
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.title}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </ScrollArea>

      <div className="mt-auto px-3 py-2 fixed bottom-0 w-64 border-t bg-background pt-2">
        <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground">
          <LogOut className="mr-2 h-4 w-4" />
          Log out
        </Button>
      </div>
    </aside>
  )
}

