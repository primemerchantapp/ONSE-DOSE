"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"
import { Line, Bar, Pie } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend)

export default function StatisticsPage() {
  const [timeRange, setTimeRange] = useState("month")

  // Mock data for users over time
  const userChartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [
      {
        label: "Secretaries",
        data: [250, 375, 420, 550, 680, 720],
        borderColor: "#8b5cf6", // purple-500
        backgroundColor: "#8b5cf6",
        tension: 0.3,
      },
      {
        label: "Bosses",
        data: [320, 420, 510, 590, 650, 710],
        borderColor: "#3b82f6", // blue-500
        backgroundColor: "#3b82f6",
        tension: 0.3,
      },
    ],
  }

  // Mock data for transactions
  const transactionChartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [
      {
        label: "Transactions",
        data: [25, 38, 42, 55, 68, 72],
        backgroundColor: "#10b981", // emerald-500
      },
    ],
  }

  // Mock data for user roles distribution
  const userRolesData = {
    labels: ["Secretaries", "Bosses"],
    datasets: [
      {
        data: [720, 710],
        backgroundColor: ["#8b5cf6", "#3b82f6"], // purple-500, blue-500
        borderColor: ["#8b5cf680", "#3b82f680"],
        borderWidth: 1,
      },
    ],
  }

  // Mock data for transaction status distribution
  const transactionStatusData = {
    labels: ["Approved", "Pending", "Rejected"],
    datasets: [
      {
        data: [75, 15, 10],
        backgroundColor: ["#10b981", "#f59e0b", "#ef4444"], // emerald-500, amber-500, red-500
        borderColor: ["#10b98180", "#f59e0b80", "#ef444480"],
        borderWidth: 1,
      },
    ],
  }

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "top" as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  }

  const pieOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top" as const,
      },
    },
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">Statistics</h1>

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-xl font-semibold">Analytics Overview</h2>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">Last 7 days</SelectItem>
            <SelectItem value="month">Last 30 days</SelectItem>
            <SelectItem value="quarter">Last 90 days</SelectItem>
            <SelectItem value="year">Last 12 months</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="distributions">Distributions</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>User Growth</CardTitle>
              <CardDescription>Number of users registered over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <Line data={userChartData} options={options} />
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Active Users</CardTitle>
                <CardDescription>Users active in the last 24 hours</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-5xl font-bold">432</div>
                  <p className="text-sm text-muted-foreground mt-2">30% of total users</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>New Registrations</CardTitle>
                <CardDescription>New users registered in the selected period</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-5xl font-bold">124</div>
                  <p className="text-sm text-muted-foreground mt-2">+8% from previous period</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Transaction Volume</CardTitle>
              <CardDescription>Number of transactions over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <Bar data={transactionChartData} options={options} />
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Total Volume</CardTitle>
                <CardDescription>Total transaction amount</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl font-bold">$24,565</div>
                  <p className="text-sm text-muted-foreground mt-2">+15% from previous period</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Approval Rate</CardTitle>
                <CardDescription>Percentage of approved transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl font-bold">75%</div>
                  <p className="text-sm text-muted-foreground mt-2">+5% from previous period</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Value</CardTitle>
                <CardDescription>Average transaction value</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl font-bold">$226</div>
                  <p className="text-sm text-muted-foreground mt-2">-2% from previous period</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="distributions" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>User Distribution by Role</CardTitle>
                <CardDescription>Breakdown of users by their assigned roles</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <Pie data={userRolesData} options={pieOptions} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Transaction Status Distribution</CardTitle>
                <CardDescription>Breakdown of transactions by their status</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <Pie data={transactionStatusData} options={pieOptions} />
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Key Metrics Summary</CardTitle>
              <CardDescription>Overview of important platform metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <div className="flex flex-col items-center gap-2 rounded-lg border p-4">
                  <div className="text-sm font-medium text-muted-foreground">Total Users</div>
                  <div className="text-3xl font-bold">1,430</div>
                </div>

                <div className="flex flex-col items-center gap-2 rounded-lg border p-4">
                  <div className="text-sm font-medium text-muted-foreground">Active Rate</div>
                  <div className="text-3xl font-bold">30%</div>
                </div>

                <div className="flex flex-col items-center gap-2 rounded-lg border p-4">
                  <div className="text-sm font-medium text-muted-foreground">Transactions</div>
                  <div className="text-3xl font-bold">432</div>
                </div>

                <div className="flex flex-col items-center gap-2 rounded-lg border p-4">
                  <div className="text-sm font-medium text-muted-foreground">Revenue</div>
                  <div className="text-3xl font-bold">$24.5K</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

