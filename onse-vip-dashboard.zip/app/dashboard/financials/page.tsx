"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { CheckCircle2, Clock, MoreHorizontal, Search, XCircle, Download, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function FinancialsPage() {
  // Mock transaction data
  const initialTransactions = [
    {
      id: 1,
      user: "John Doe",
      amount: "$320.00",
      type: "Credit",
      status: "Approved",
      date: "2023-06-15",
      time: "14:30",
    },
    {
      id: 2,
      user: "Jane Smith",
      amount: "$150.00",
      type: "Credit",
      status: "Pending",
      date: "2023-06-15",
      time: "10:15",
    },
    {
      id: 3,
      user: "Robert Johnson",
      amount: "$200.00",
      type: "Credit",
      status: "Approved",
      date: "2023-06-14",
      time: "09:45",
    },
    {
      id: 4,
      user: "Emily Williams",
      amount: "$500.00",
      type: "Credit",
      status: "Rejected",
      date: "2023-06-14",
      time: "16:20",
    },
    {
      id: 5,
      user: "Michael Brown",
      amount: "$120.00",
      type: "Credit",
      status: "Approved",
      date: "2023-06-13",
      time: "13:10",
    },
    {
      id: 6,
      user: "Sarah Davis",
      amount: "$250.00",
      type: "Credit",
      status: "Pending",
      date: "2023-06-13",
      time: "11:30",
    },
    {
      id: 7,
      user: "David Miller",
      amount: "$180.00",
      type: "Credit",
      status: "Approved",
      date: "2023-06-12",
      time: "15:45",
    },
    {
      id: 8,
      user: "Jessica Wilson",
      amount: "$420.00",
      type: "Credit",
      status: "Pending",
      date: "2023-06-12",
      time: "09:00",
    },
    {
      id: 9,
      user: "Thomas Moore",
      amount: "$300.00",
      type: "Credit",
      status: "Rejected",
      date: "2023-06-11",
      time: "14:15",
    },
  ]

  const [transactions, setTransactions] = useState(initialTransactions)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("All")

  // Filter transactions based on search query and status filter
  const filteredTransactions = transactions.filter((transaction) => {
    // Search filter
    const matchesSearch = transaction.user.toLowerCase().includes(searchQuery.toLowerCase())

    // Status filter
    const matchesStatus = statusFilter === "All" || transaction.status === statusFilter

    return matchesSearch && matchesStatus
  })

  // Update transaction status
  const updateTransactionStatus = (transactionId: number, newStatus: string) => {
    setTransactions(
      transactions.map((transaction) => {
        if (transaction.id === transactionId) {
          return { ...transaction, status: newStatus }
        }
        return transaction
      }),
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">Financials</h1>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">432</div>
            <p className="text-xs text-muted-foreground">+22% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Credit Issued</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$24,565.00</div>
            <p className="text-xs text-muted-foreground">+15% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32</div>
            <p className="text-xs text-muted-foreground">-5% from last month</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Credit Transactions</CardTitle>
          <CardDescription>Manage credit transactions and approval statuses.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search transactions..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Status</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="icon" title="Export">
                <Download className="h-4 w-4" />
              </Button>

              <Button variant="outline" size="icon" title="Advanced Filters">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransactions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-4">
                      No transactions found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell className="font-medium">{transaction.user}</TableCell>
                      <TableCell>{transaction.amount}</TableCell>
                      <TableCell>{transaction.type}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {transaction.status === "Approved" ? (
                            <CheckCircle2 className="mr-1 h-4 w-4 text-green-500" />
                          ) : transaction.status === "Pending" ? (
                            <Clock className="mr-1 h-4 w-4 text-amber-500" />
                          ) : (
                            <XCircle className="mr-1 h-4 w-4 text-red-500" />
                          )}
                          <span
                            className={
                              transaction.status === "Approved"
                                ? "text-green-500"
                                : transaction.status === "Pending"
                                  ? "text-amber-500"
                                  : "text-red-500"
                            }
                          >
                            {transaction.status}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {transaction.date} at {transaction.time}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>View details</DropdownMenuItem>
                            {transaction.status === "Pending" && (
                              <>
                                <DropdownMenuItem onClick={() => updateTransactionStatus(transaction.id, "Approved")}>
                                  <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                                  <span>Approve</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => updateTransactionStatus(transaction.id, "Rejected")}>
                                  <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                  <span>Reject</span>
                                </DropdownMenuItem>
                              </>
                            )}
                            {transaction.status === "Approved" && (
                              <DropdownMenuItem onClick={() => updateTransactionStatus(transaction.id, "Rejected")}>
                                <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                <span>Mark as Rejected</span>
                              </DropdownMenuItem>
                            )}
                            {transaction.status === "Rejected" && (
                              <DropdownMenuItem onClick={() => updateTransactionStatus(transaction.id, "Approved")}>
                                <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                                <span>Mark as Approved</span>
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

