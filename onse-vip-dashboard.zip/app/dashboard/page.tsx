import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUpRight, Users, DollarSign, CreditCard, CheckCircle2, Clock } from "lucide-react"
import {
  getTotalUsers,
  getNewRegistrations,
  getTotalRevenue,
  getPendingTransactions,
  getRecentTransactions,
  getUserStatistics,
} from "@/lib/firebaseUtils"

export default async function DashboardPage() {
  const totalUsers = await getTotalUsers()
  const newRegistrations = await getNewRegistrations()
  const totalRevenue = await getTotalRevenue()
  const pendingTransactions = await getPendingTransactions()
  const recentTransactions = await getRecentTransactions()
  const userStats = await getUserStatistics()

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">Dashboard</h1>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
            <p className="text-xs text-muted-foreground flex items-center pt-1">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                {((newRegistrations / totalUsers) * 100).toFixed(1)}%
              </span>
              <span className="ml-1">from last month</span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">New Registrations</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{newRegistrations}</div>
            <p className="text-xs text-muted-foreground flex items-center pt-1">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                New users
              </span>
              <span className="ml-1">in the last 30 days</span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground flex items-center pt-1">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                Total approved transactions
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Transactions</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingTransactions}</div>
            <p className="text-xs text-muted-foreground flex items-center pt-1">
              <span className="text-amber-500 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                Awaiting approval
              </span>
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
            <CardDescription>Overview of the latest credit transactions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="font-medium">{transaction.user}</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="font-medium">${Number.parseFloat(transaction.amount).toFixed(2)}</div>
                    <div className="flex items-center">
                      {transaction.status === "approved" ? (
                        <CheckCircle2 className="mr-1 h-4 w-4 text-green-500" />
                      ) : (
                        <Clock className="mr-1 h-4 w-4 text-amber-500" />
                      )}
                      <span className={transaction.status === "approved" ? "text-green-500" : "text-amber-500"}>
                        {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(transaction.timestamp).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>User Statistics</CardTitle>
            <CardDescription>Distribution by role</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">Secretaries</div>
                  <div className="text-right text-sm text-muted-foreground">{userStats.secretaries} users</div>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{
                      width: `${((userStats.secretaries / (userStats.secretaries + userStats.bosses)) * 100).toFixed(1)}%`,
                    }}
                  ></div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">Bosses</div>
                  <div className="text-right text-sm text-muted-foreground">{userStats.bosses} users</div>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{
                      width: `${((userStats.bosses / (userStats.secretaries + userStats.bosses)) * 100).toFixed(1)}%`,
                    }}
                  ></div>
                </div>
              </div>

              <div className="pt-4">
                <div className="rounded-md bg-muted p-4">
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-sm font-medium">Total Users</p>
                      <p className="text-xs text-muted-foreground">All registered users</p>
                    </div>
                    <div className="ml-auto text-xl font-bold">{totalUsers}</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

