import { ref, get } from "firebase/database"
import { db } from "./firebase"

interface OnseUser {
  appName: string
  availableDays: string[]
  availableTimeSlots: string[]
  created_at: number
  description: string
  email: string
  interests: string[]
  languages: string[]
  location: string
  name: string
  photos: string[]
  privatePhotos: string[]
  profileCompleted: boolean
  rate: number
  unavailableDates: string[]
  usertype: "secretary" | "boss"
  videoUrl: string
}

function isOnseUser(user: any): user is OnseUser {
  return user && user.appName === "onse"
}

export async function getTotalUsers() {
  const usersRef = ref(db, "users")
  const snapshot = await get(usersRef)
  let count = 0
  snapshot.forEach((childSnapshot) => {
    if (isOnseUser(childSnapshot.val())) {
      count++
    }
  })
  return count
}

export async function getNewRegistrations(days = 30) {
  const usersRef = ref(db, "users")
  const snapshot = await get(usersRef)

  const thirtyDaysAgo = Date.now() - days * 24 * 60 * 60 * 1000
  let count = 0
  snapshot.forEach((childSnapshot) => {
    const userData = childSnapshot.val()
    if (isOnseUser(userData) && userData.created_at && userData.created_at > thirtyDaysAgo) {
      count++
    }
  })

  return count
}

export async function getUserStatistics() {
  const usersRef = ref(db, "users")
  const snapshot = await get(usersRef)
  let secretaries = 0
  let bosses = 0
  snapshot.forEach((childSnapshot) => {
    const userData = childSnapshot.val()
    if (isOnseUser(userData)) {
      if (userData.usertype === "secretary") {
        secretaries++
      } else if (userData.usertype === "boss") {
        bosses++
      }
    }
  })
  return { secretaries, bosses }
}

// The following functions remain the same as they don't directly involve the users collection
export async function getTotalRevenue() {
  const transactionsRef = ref(db, "transactions")
  const snapshot = await get(transactionsRef)
  let total = 0
  snapshot.forEach((childSnapshot) => {
    const transaction = childSnapshot.val()
    if (transaction.status === "approved") {
      total += Number.parseFloat(transaction.amount)
    }
  })
  return total
}

export async function getPendingTransactions() {
  const transactionsRef = ref(db, "transactions")
  const snapshot = await get(transactionsRef)
  let count = 0
  snapshot.forEach((childSnapshot) => {
    const transaction = childSnapshot.val()
    if (transaction.status === "pending") {
      count++
    }
  })
  return count
}

export async function getRecentTransactions(limit = 5) {
  const transactionsRef = ref(db, "transactions")
  const snapshot = await get(transactionsRef)
  const transactions = []
  snapshot.forEach((childSnapshot) => {
    transactions.push({ id: childSnapshot.key, ...childSnapshot.val() })
  })
  // Sort transactions by timestamp in descending order and take the last 'limit' items
  return transactions.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit)
}

