"use client"

import { OnseLogo } from "@/components/ui/onse-logo"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"

export const RoleSelection = () => {
  const [selectedRole, setSelectedRole] = useState<"boss" | "secretary" | null>(null)
  const router = useRouter()

  const handleContinue = () => {
    if (selectedRole) {
      localStorage.setItem("userRole", selectedRole)
      router.push("/signup")
    }
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-6 bg-black text-white">
      <div className="flex flex-col items-center justify-center max-w-md w-full space-y-8">
        <OnseLogo size={120} />

        <div className="text-center space-y-2">
          <h1 className="text-2xl font-bold">Choose Your Role</h1>
          <p className="text-gray-400">Select how you want to use Onse</p>
        </div>

        <div className="w-full space-y-4 mt-4">
          <div
            className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
              selectedRole === "boss" ? "border-neon-pink bg-neon-pink/10" : "border-gray-800 hover:border-gray-700"
            }`}
            onClick={() => setSelectedRole("boss")}
          >
            <h3 className="text-xl font-semibold">Boss</h3>
            <p className="text-gray-400">I want to hire a secretary</p>
          </div>

          <div
            className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
              selectedRole === "secretary"
                ? "border-neon-purple bg-neon-purple/10"
                : "border-gray-800 hover:border-gray-700"
            }`}
            onClick={() => setSelectedRole("secretary")}
          >
            <h3 className="text-xl font-semibold">Secretary</h3>
            <p className="text-gray-400">I want to offer my services</p>
          </div>
        </div>

        <div className="w-full mt-6">
          <Button neon fullWidth disabled={!selectedRole} onClick={handleContinue}>
            Continue
          </Button>

          <div className="mt-4 text-center">
            <Link href="/login" className="text-gray-400 hover:text-white">
              Already have an account? <span className="underline">Login</span>
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}

