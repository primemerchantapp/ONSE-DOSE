"use client"

import { useEffect, useState } from "react"
import { collection, query, where, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../providers"
import { BottomNav } from "@/components/bottom-nav"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Loader2 } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"

interface Booking {
  id: string
  secretaryId: string
  secretaryName: string
  secretaryPhoto: string
  date: string
  time: string
  duration: number
  totalAmount: number
  status: "pending" | "confirmed" | "completed" | "cancelled"
}

export default function BookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const [showSuccess, setShowSuccess] = useState(false)
  const { user } = useAuth()
  const searchParams = useSearchParams()
  const router = useRouter()

  useEffect(() => {
    // Check for success parameter in URL
    if (searchParams.get("success") === "true") {
      setShowSuccess(true)
      // Remove success parameter after 3 seconds
      setTimeout(() => {
        router.replace("/bookings")
      }, 3000)
    }

    const fetchBookings = async () => {
      if (!user) return

      try {
        const q = query(collection(db, "bookings"), where("clientId", "==", user.uid))

        const querySnapshot = await getDocs(q)
        const bookingsData: Booking[] = []

        for (const doc of querySnapshot.docs) {
          const data = doc.data()

          // Fetch secretary details
          const secretaryDoc = await getDocs(doc(db, "users", data.secretaryId))
          const secretaryData = secretaryDoc.data()

          bookingsData.push({
            id: doc.id,
            secretaryId: data.secretaryId,
            secretaryName: secretaryData?.name || "Professional Secretary",
            secretaryPhoto: secretaryData?.photos?.[0] || "/placeholder.svg?height=100&width=100",
            date: data.date,
            time: data.time,
            duration: data.duration,
            totalAmount: data.totalAmount,
            status: data.status,
          })
        }

        // Sort bookings by date (most recent first)
        bookingsData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

        setBookings(bookingsData)
      } catch (error) {
        console.error("Error fetching bookings:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchBookings()
  }, [user, searchParams, router])

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
    return new Date(dateString).toLocaleDateString("en-US", options)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "text-green-500 bg-green-500/10"
      case "completed":
        return "text-blue-500 bg-blue-500/10"
      case "cancelled":
        return "text-red-500 bg-red-500/10"
      default:
        return "text-yellow-500 bg-yellow-500/10"
    }
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <h1 className="text-2xl font-bold">Your Bookings</h1>
      </header>

      {showSuccess && (
        <div className="mx-4 mb-4 p-4 bg-green-500/20 border border-green-500 rounded-lg">
          <p className="text-green-500">Booking created successfully!</p>
        </div>
      )}

      <div className="p-4">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-neon-pink" />
          </div>
        ) : (
          <>
            {bookings.length === 0 ? (
              <div className="text-center py-8 space-y-4">
                <Calendar className="h-16 w-16 mx-auto text-gray-600" />
                <p className="text-gray-400">You don't have any bookings yet</p>
                <Link href="/dashboard">
                  <Button neon>Find a Secretary</Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {bookings.map((booking) => (
                  <div key={booking.id} className="bg-gray-900 rounded-xl overflow-hidden">
                    <div className="p-4 flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full overflow-hidden">
                        <Image
                          src={booking.secretaryPhoto || "/placeholder.svg"}
                          alt={booking.secretaryName}
                          width={48}
                          height={48}
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold">{booking.secretaryName}</h3>
                        <div className="flex items-center text-sm text-gray-400">
                          <Calendar className="h-3 w-3 mr-1" />
                          {formatDate(booking.date)}
                        </div>
                        <div className="flex items-center text-sm text-gray-400">
                          <Clock className="h-3 w-3 mr-1" />
                          {booking.time} ({booking.duration} hour{booking.duration > 1 ? "s" : ""})
                        </div>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-xs ${getStatusColor(booking.status)}`}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </div>
                    </div>
                    <div className="border-t border-gray-800 p-4 flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-400">Total</p>
                        <p className="font-semibold text-neon-pink">{booking.totalAmount} ONS</p>
                      </div>
                      <Link href={`/booking-details/${booking.id}`}>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

