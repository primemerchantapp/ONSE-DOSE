"use client"

import { useEffect, useState, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { doc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ArrowLeft, Calendar, Clock, MapPin, Star, Play } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { ImageViewerModal } from "@/components/image-viewer-modal"

interface SecretaryProfile {
  id: string
  name: string
  location: string
  description: string
  rate: number
  photos: string[]
  languages: string[]
  interests: string[]
  experience: string
  availability: string[]
  rating: number
  videoUrl?: string
}

export default function SecretaryProfile() {
  const [profile, setProfile] = useState<SecretaryProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [showImageViewer, setShowImageViewer] = useState(false)
  const [initialImageIndex, setInitialImageIndex] = useState(0)
  const videoRef = useRef<HTMLVideoElement>(null)
  const params = useParams()
  const router = useRouter()
  const { id } = params

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const docRef = doc(db, "users", id as string)
        const docSnap = await getDoc(docRef)

        if (docSnap.exists()) {
          const data = docSnap.data()
          setProfile({
            id: docSnap.id,
            name: data.name || "Professional Secretary",
            location: data.location || "Remote",
            description: data.description || "Professional secretary available for hire",
            rate: data.rate || 1000,
            photos: data.photos || ["/placeholder.svg?height=400&width=400"],
            languages: data.languages || ["English"],
            interests: data.interests || ["Organization", "Administration"],
            experience: data.experience || "5+ years of experience as a professional secretary",
            availability: data.availability || ["Weekdays", "Weekends"],
            rating: data.rating || 4.8,
            videoUrl: data.videoUrl,
          })
        } else {
          router.push("/dashboard")
        }
      } catch (error) {
        console.error("Error fetching secretary profile:", error)
      } finally {
        setLoading(false)
      }
    }

    if (id) {
      fetchProfile()
    }
  }, [id, router])

  const handleImageClick = (index: number) => {
    setInitialImageIndex(index)
    setShowImageViewer(true)
  }

  const handleVideoFullScreen = () => {
    if (videoRef.current) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen()
      } else if (videoRef.current.webkitRequestFullscreen) {
        videoRef.current.webkitRequestFullscreen()
      }
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="animate-spin h-8 w-8 border-t-2 border-neon-pink rounded-full"></div>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <p>Secretary not found</p>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Secretary Profile</h1>
      </header>

      <div className="relative h-80">
        <Image
          src={profile.photos[0] || "/placeholder.svg"}
          alt={profile.name}
          fill
          className="object-cover"
          onClick={() => handleImageClick(0)}
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
          <h2 className="text-2xl font-bold">{profile.name}</h2>
          <div className="flex items-center text-sm">
            <MapPin className="h-4 w-4 mr-1" />
            <span>{profile.location}</span>
            <div className="ml-auto flex items-center">
              <Star className="h-4 w-4 text-yellow-400 mr-1" />
              <span>{profile.rating.toFixed(1)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-400">Hourly Rate</p>
            <p className="text-2xl font-bold text-neon-pink">{profile.rate} credits/hr</p>
          </div>
          <Link href={`/booking/${profile.id}`}>
            <Button neon>
              <Calendar className="h-4 w-4 mr-2" />
              Book Now
            </Button>
          </Link>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">About</h3>
          <p className="text-gray-300">{profile.description}</p>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Experience</h3>
          <p className="text-gray-300">{profile.experience}</p>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Languages</h3>
          <div className="flex flex-wrap gap-2">
            {profile.languages.map((language, index) => (
              <span key={index} className="px-3 py-1 bg-gray-800 rounded-full text-sm">
                {language}
              </span>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Interests</h3>
          <div className="flex flex-wrap gap-2">
            {profile.interests.map((interest, index) => (
              <span key={index} className="px-3 py-1 bg-gray-800 rounded-full text-sm">
                {interest}
              </span>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Availability</h3>
          <div className="flex flex-wrap gap-2">
            {profile.availability.map((day, index) => (
              <div key={index} className="flex items-center px-3 py-1 bg-gray-800 rounded-full text-sm">
                <Clock className="h-3 w-3 mr-1" />
                {day}
              </div>
            ))}
          </div>
        </div>

        {profile.videoUrl && (
          <div>
            <h3 className="text-lg font-semibold mb-2">Introduction Video</h3>
            <div className="relative aspect-video rounded-lg overflow-hidden">
              <video ref={videoRef} src={profile.videoUrl} className="w-full h-full object-cover" controls />
              <button
                onClick={handleVideoFullScreen}
                className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 hover:opacity-100 transition-opacity"
              >
                <Play className="h-12 w-12 text-white" />
              </button>
            </div>
          </div>
        )}

        <div>
          <h3 className="text-lg font-semibold mb-2">Photos</h3>
          <div className="grid grid-cols-3 gap-2">
            {profile.photos.map((photo, index) => (
              <div
                key={index}
                className="aspect-square rounded-lg overflow-hidden cursor-pointer"
                onClick={() => handleImageClick(index)}
              >
                <Image
                  src={photo || "/placeholder.svg"}
                  alt={`${profile.name} photo ${index + 1}`}
                  width={150}
                  height={150}
                  className="object-cover w-full h-full"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />

      {showImageViewer && (
        <ImageViewerModal
          images={profile.photos}
          initialIndex={initialImageIndex}
          onClose={() => setShowImageViewer(false)}
        />
      )}
    </main>
  )
}

