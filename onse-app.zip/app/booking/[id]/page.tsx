"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { doc, getDoc, addDoc, collection, serverTimestamp } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../../providers"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Calendar, Clock } from "lucide-react"
import Image from "next/image"
import { sendNotification } from "@/lib/notificationService"

interface SecretaryBasic {
  id: string
  name: string
  photoURL: string
  rate: number
}

const timeSlots = [
  "09:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "01:00 PM",
  "02:00 PM",
  "03:00 PM",
  "04:00 PM",
  "05:00 PM",
  "06:00 PM",
  "07:00 PM",
  "08:00 PM",
]

const INITIAL_RATE = 2500
const INITIAL_HOURS = 3
const ADDITIONAL_RATE = 500

export default function BookingPage() {
  const [secretary, setSecretary] = useState<SecretaryBasic | null>(null)
  const [selectedDate, setSelectedDate] = useState<string>("")
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [duration, setDuration] = useState<number>(1)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const { user } = useAuth()
  const params = useParams()
  const router = useRouter()
  const { id } = params

  useEffect(() => {
    const fetchSecretaryBasic = async () => {
      try {
        const docRef = doc(db, "users", id as string)
        const docSnap = await getDoc(docRef)

        if (docSnap.exists()) {
          const data = docSnap.data()
          setSecretary({
            id: docSnap.id,
            name: data.name || "Professional Secretary",
            photoURL: data.photos?.[0] || "/placeholder.svg?height=100&width=100",
            rate: data.rate || 1000,
          })
        } else {
          router.push("/dashboard")
        }
      } catch (error) {
        console.error("Error fetching secretary data:", error)
      } finally {
        setLoading(false)
      }
    }

    // Set default date to tomorrow
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    setSelectedDate(tomorrow.toISOString().split("T")[0])

    if (id) {
      fetchSecretaryBasic()
    }
  }, [id, router])

  const calculateTotalAmount = (hours: number) => {
    if (hours <= INITIAL_HOURS) {
      return INITIAL_RATE
    }
    return INITIAL_RATE + (hours - INITIAL_HOURS) * ADDITIONAL_RATE
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user || !secretary || !selectedDate || !selectedTime) {
      return
    }

    setSubmitting(true)

    try {
      const totalAmount = calculateTotalAmount(duration)
      const secretaryPayment = 1500 + (duration > INITIAL_HOURS ? (duration - INITIAL_HOURS) * ADDITIONAL_RATE : 0)
      const onseAppFee = totalAmount - secretaryPayment

      // Create booking in Firestore
      const bookingRef = await addDoc(collection(db, "bookings"), {
        secretaryId: secretary.id,
        clientId: user.uid,
        date: selectedDate,
        time: selectedTime,
        duration: duration,
        totalAmount: totalAmount,
        secretaryPayment: secretaryPayment,
        onseAppFee: onseAppFee,
        status: "pending",
        createdAt: serverTimestamp(),
      })

      // Send notification to secretary
      await sendNotification(
        secretary.id,
        "New Booking Request",
        `You have a new booking request for ${selectedDate} at ${selectedTime}.`,
        { bookingId: bookingRef.id },
      )

      // Send notification to client (boss)
      await sendNotification(
        user.uid,
        "Booking Confirmation",
        `Your booking request for ${selectedDate} at ${selectedTime} has been sent to the secretary.`,
        { bookingId: bookingRef.id },
      )

      // Redirect to bookings page
      router.push("/bookings?success=true")
    } catch (error) {
      console.error("Error creating booking:", error)
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="animate-spin h-8 w-8 border-t-2 border-neon-pink rounded-full"></div>
      </div>
    )
  }

  if (!secretary) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <p>Secretary not found</p>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Book a Session</h1>
      </header>

      <div className="p-4">
        <div className="flex items-center space-x-4 mb-6 p-4 bg-gray-900 rounded-xl">
          <div className="w-16 h-16 rounded-full overflow-hidden">
            <Image
              src={secretary.photoURL || "/placeholder.svg"}
              alt={secretary.name}
              width={64}
              height={64}
              className="object-cover w-full h-full"
            />
          </div>
          <div>
            <h2 className="text-lg font-semibold">{secretary.name}</h2>
            <p className="text-neon-pink font-medium">{secretary.rate} credits/hr</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              <Calendar className="inline h-4 w-4 mr-2" />
              Select Date
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              min={new Date().toISOString().split("T")[0]}
              className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              <Clock className="inline h-4 w-4 mr-2" />
              Select Time
            </label>
            <div className="grid grid-cols-4 gap-2">
              {timeSlots.map((time) => (
                <button
                  key={time}
                  type="button"
                  className={`py-2 px-3 rounded-lg text-sm ${
                    selectedTime === time
                      ? "bg-neon-pink text-white"
                      : "bg-gray-900 border border-gray-700 hover:border-gray-500"
                  }`}
                  onClick={() => setSelectedTime(time)}
                >
                  {time}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Duration (hours)</label>
            <div className="flex items-center space-x-4">
              <button
                type="button"
                className="w-10 h-10 rounded-full bg-gray-900 border border-gray-700 flex items-center justify-center"
                onClick={() => setDuration(Math.max(1, duration - 1))}
              >
                -
              </button>
              <span className="text-xl font-semibold">{duration}</span>
              <button
                type="button"
                className="w-10 h-10 rounded-full bg-gray-900 border border-gray-700 flex items-center justify-center"
                onClick={() => setDuration(Math.min(8, duration + 1))}
              >
                +
              </button>
            </div>
          </div>

          <div className="bg-gray-900 rounded-xl p-4 space-y-2">
            <div className="flex justify-between">
              <span>Base rate (first 3 hours)</span>
              <span>{INITIAL_RATE} credits</span>
            </div>
            {duration > INITIAL_HOURS && (
              <div className="flex justify-between">
                <span>
                  Additional hours ({duration - INITIAL_HOURS} x {ADDITIONAL_RATE} credits)
                </span>
                <span>{(duration - INITIAL_HOURS) * ADDITIONAL_RATE} credits</span>
              </div>
            )}
            <div className="border-t border-gray-800 my-2 pt-2 flex justify-between font-semibold">
              <span>Total</span>
              <span className="text-neon-pink">{calculateTotalAmount(duration)} credits</span>
            </div>
          </div>

          <Button type="submit" neon fullWidth isLoading={submitting}>
            Confirm Booking
          </Button>
        </form>
      </div>
    </main>
  )
}

