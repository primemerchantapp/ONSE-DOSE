"use client"

import { useEffect, useState } from "react"
import { collection, query, where, orderBy, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../../providers"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ArrowLeft, Clock, CheckCircle, XCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"

interface Payment {
  id: string
  amount: number
  onsCredits: number
  paymentMethod: string
  status: "pending" | "confirmed" | "rejected"
  createdAt: Date
  screenshotURL: string
  note?: string
}

export default function PaymentHistoryPage() {
  const [payments, setPayments] = useState<Payment[]>([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    const fetchPayments = async () => {
      if (!user) return

      try {
        const q = query(collection(db, "payments"), where("userId", "==", user.uid), orderBy("createdAt", "desc"))

        const querySnapshot = await getDocs(q)
        const paymentsData: Payment[] = []

        querySnapshot.forEach((doc) => {
          const data = doc.data()
          paymentsData.push({
            id: doc.id,
            amount: data.amount,
            onsCredits: data.onsCredits,
            paymentMethod: data.paymentMethod,
            status: data.status,
            createdAt: data.createdAt ? new Date(data.createdAt.seconds * 1000) : new Date(),
            screenshotURL: data.screenshotURL,
            note: data.note,
          })
        })

        setPayments(paymentsData)
      } catch (error) {
        console.error("Error fetching payments:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPayments()
  }, [user])

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "rejected":
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return <Clock className="h-5 w-5 text-yellow-500" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Confirmed"
      case "rejected":
        return "Rejected"
      default:
        return "Pending"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "text-green-500 bg-green-500/10"
      case "rejected":
        return "text-red-500 bg-red-500/10"
      default:
        return "text-yellow-500 bg-yellow-500/10"
    }
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Payment History</h1>
      </header>

      <div className="p-4">
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin h-8 w-8 border-t-2 border-neon-pink rounded-full"></div>
          </div>
        ) : (
          <>
            {payments.length === 0 ? (
              <div className="text-center py-8 space-y-4">
                <p className="text-gray-400">You haven't made any payments yet</p>
                <Button onClick={() => router.push("/credits")} neon>
                  Add Credits
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {payments.map((payment) => (
                  <div key={payment.id} className="bg-gray-900 rounded-xl overflow-hidden">
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="font-semibold">{payment.onsCredits} Credits</div>
                          <div className="text-sm text-gray-400">{formatDate(payment.createdAt)}</div>
                        </div>
                        <div
                          className={`px-3 py-1 rounded-full text-xs flex items-center gap-1 ${getStatusColor(payment.status)}`}
                        >
                          {getStatusIcon(payment.status)}
                          <span>{getStatusText(payment.status)}</span>
                        </div>
                      </div>

                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Amount</span>
                        <span>₱{payment.amount.toLocaleString()}</span>
                      </div>

                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Method</span>
                        <span>{payment.paymentMethod}</span>
                      </div>

                      {payment.note && (
                        <div className="mt-2 text-sm text-gray-400">
                          <div>Note:</div>
                          <div className="italic">{payment.note}</div>
                        </div>
                      )}
                    </div>

                    <div className="border-t border-gray-800">
                      <div className="p-2">
                        <div className="text-xs text-gray-500 mb-1">Payment Screenshot</div>
                        <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
                          <Image
                            src={payment.screenshotURL || "/placeholder.svg"}
                            alt="Payment screenshot"
                            layout="fill"
                            objectFit="cover"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

