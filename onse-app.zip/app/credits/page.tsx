"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { collection, addDoc, serverTimestamp } from "firebase/firestore"
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"
import { db, storage } from "@/lib/firebase"
import { useAuth } from "../providers"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ArrowLeft, Upload, Copy, Check } from "lucide-react"
import Image from "next/image"

const PAYMENT_METHODS = [
  {
    name: "Maya",
    account: "0968 501 8523",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/maya-logo.jpg-fzQ6e9DTIuCssALdwEwIdacnK8reF6.jpeg",
  },
  {
    name: "GCash",
    account: "0915 633 8247",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Fresco_Jonaline_2023_Page_09-KT3DMWv1j9Z5Mb1IpF1ogST7LrhBjn.webp",
  },
]

const CREDIT_PACKAGES = [
  { amount: 500, ons: 500, label: "Basic" },
  { amount: 1000, ons: 1100, label: "Standard", popular: true },
  { amount: 2000, ons: 2300, label: "Premium" },
  { amount: 5000, ons: 6000, label: "Ultimate" },
]

export default function CreditsPage() {
  const [selectedMethod, setSelectedMethod] = useState(PAYMENT_METHODS[0])
  const [selectedPackage, setSelectedPackage] = useState(CREDIT_PACKAGES[1])
  const [screenshot, setScreenshot] = useState<File | null>(null)
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null)
  const [note, setNote] = useState("")
  const [copied, setCopied] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()
  const { user } = useAuth()

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files.length) return

    const file = e.target.files[0]
    setScreenshot(file)
    setScreenshotPreview(URL.createObjectURL(file))
  }

  const copyAccountNumber = () => {
    navigator.clipboard.writeText(selectedMethod.account)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !screenshot) return

    setSubmitting(true)

    try {
      // Upload screenshot to Firebase Storage
      const screenshotRef = ref(storage, `payments/${user.uid}/${Date.now()}_${screenshot.name}`)
      await uploadBytes(screenshotRef, screenshot)
      const screenshotURL = await getDownloadURL(screenshotRef)

      // Add payment record to Firestore
      await addDoc(collection(db, "payments"), {
        userId: user.uid,
        amount: selectedPackage.amount,
        onsCredits: selectedPackage.ons,
        paymentMethod: selectedMethod.name,
        paymentAccount: selectedMethod.account,
        screenshotURL,
        note,
        status: "pending",
        createdAt: serverTimestamp(),
      })

      // Redirect to payment success page
      router.push("/credits/success")
    } catch (error) {
      console.error("Error submitting payment:", error)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Add Credits</h1>
      </header>

      <div className="p-4 space-y-6">
        <div>
          <h2 className="text-lg font-semibold mb-2">Select Credit Package</h2>
          <div className="grid grid-cols-2 gap-3">
            {CREDIT_PACKAGES.map((pkg) => (
              <div
                key={pkg.amount}
                className={`p-3 rounded-xl border-2 cursor-pointer relative ${
                  selectedPackage.amount === pkg.amount
                    ? "border-neon-pink bg-neon-pink/10"
                    : "border-gray-800 hover:border-gray-700"
                }`}
                onClick={() => setSelectedPackage(pkg)}
              >
                {pkg.popular && (
                  <div className="absolute -top-2 -right-2 bg-neon-pink text-white text-xs px-2 py-0.5 rounded-full">
                    Popular
                  </div>
                )}
                <div className="text-xl font-bold">{pkg.ons} credits</div>
                <div className="text-gray-400">₱{pkg.amount.toLocaleString()}</div>
                <div className="text-xs text-gray-500">{pkg.label} Package</div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-2">Select Payment Method</h2>
          <div className="flex space-x-3">
            {PAYMENT_METHODS.map((method) => (
              <div
                key={method.name}
                className={`flex-1 p-3 rounded-xl border-2 cursor-pointer flex flex-col items-center ${
                  selectedMethod.name === method.name
                    ? "border-neon-pink bg-neon-pink/10"
                    : "border-gray-800 hover:border-gray-700"
                }`}
                onClick={() => setSelectedMethod(method)}
              >
                <div className="w-12 h-12 relative mb-2">
                  <Image
                    src={method.logo || `/placeholder.svg?height=48&width=48`}
                    alt={method.name}
                    layout="fill"
                    objectFit="contain"
                  />
                </div>
                <div className="font-medium">{method.name}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-900 rounded-xl p-4">
          <h3 className="font-semibold mb-2">Payment Details</h3>
          <p className="text-sm text-gray-400 mb-2">
            Please send your payment to the following {selectedMethod.name} account:
          </p>
          <div className="flex items-center justify-between bg-gray-800 p-3 rounded-lg mb-4">
            <span className="font-mono">{selectedMethod.account}</span>
            <button
              onClick={copyAccountNumber}
              className="text-neon-pink hover:text-neon-purple transition-colors"
              aria-label="Copy account number"
            >
              {copied ? <Check size={18} /> : <Copy size={18} />}
            </button>
          </div>
          <p className="text-sm text-gray-400">After sending payment, upload a screenshot below as proof of payment.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Upload Payment Screenshot</label>
            {screenshotPreview ? (
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden mb-2">
                <Image
                  src={screenshotPreview || "/placeholder.svg"}
                  alt="Payment screenshot"
                  layout="fill"
                  objectFit="cover"
                />
                <button
                  type="button"
                  onClick={() => {
                    setScreenshot(null)
                    setScreenshotPreview(null)
                  }}
                  className="absolute top-2 right-2 bg-black/70 rounded-full p-1"
                >
                  <ArrowLeft size={16} className="text-white" />
                </button>
              </div>
            ) : (
              <div
                className="border-2 border-dashed border-gray-700 rounded-xl p-8 text-center cursor-pointer hover:border-gray-500 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="mx-auto h-10 w-10 text-gray-400 mb-2" />
                <p className="text-sm text-gray-400">Click to upload screenshot</p>
              </div>
            )}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleScreenshotChange}
              accept="image/*"
              className="hidden"
              required
            />
          </div>

          <div>
            <label htmlFor="note" className="block text-sm font-medium text-gray-400 mb-2">
              Additional Note (Optional)
            </label>
            <textarea
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
              placeholder="Any additional information..."
              rows={3}
            />
          </div>

          <div className="bg-gray-900 rounded-xl p-4 space-y-2">
            <div className="flex justify-between">
              <span>Package</span>
              <span>{selectedPackage.ons} credits</span>
            </div>
            <div className="flex justify-between">
              <span>Payment Method</span>
              <span>{selectedMethod.name}</span>
            </div>
            <div className="border-t border-gray-800 my-2 pt-2 flex justify-between font-semibold">
              <span>Total</span>
              <span className="text-neon-pink">₱{selectedPackage.amount.toLocaleString()}</span>
            </div>
          </div>

          <Button type="submit" neon fullWidth isLoading={submitting}>
            Submit Payment
          </Button>
        </form>
      </div>

      <BottomNav />
    </main>
  )
}

