"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export default function PaymentSuccessPage() {
  const router = useRouter()

  return (
    <main className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-6">
      <div className="max-w-md w-full text-center space-y-6">
        <CheckCircle className="mx-auto h-20 w-20 text-neon-pink" />

        <h1 className="text-2xl font-bold">Payment Submitted!</h1>

        <p className="text-gray-400">
          Your payment is being processed. Credits will be added to your account once the payment is verified by our
          team.
        </p>

        <div className="bg-gray-900 rounded-xl p-4 text-left">
          <h3 className="font-semibold mb-2">What happens next?</h3>
          <ul className="text-sm text-gray-400 space-y-2">
            <li>• Our team will verify your payment</li>
            <li>• Once verified, credits will be added to your account</li>
            <li>• You'll receive a notification when credits are added</li>
            <li>• This usually takes less than 24 hours</li>
          </ul>
        </div>

        <div className="space-y-3 pt-4">
          <Button onClick={() => router.push("/credits/history")} variant="outline" fullWidth>
            View Payment History
          </Button>

          <Button onClick={() => router.push("/dashboard")} neon fullWidth>
            Return to Dashboard
          </Button>
        </div>
      </div>
    </main>
  )
}

