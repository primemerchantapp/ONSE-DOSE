"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const slides = [
  {
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%F0%9F%8C%B9%20CUTE%20%F0%9F%8C%B9-U412uzphLBnYPk8jbBgrCEzcRgYEhP.jpeg",
    title: "Professional Workspace Assistants",
    description: "Connect with dedicated secretaries who excel in office management",
  },
  {
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4cc165b6-2baf-4ae5-91b6-bfa6dbe6fe37-z6E0x71m3I97xKF4OkxmeE598ldaX9.jpeg",
    title: "Modern & Tech-Savvy",
    description: "Our secretaries are up-to-date with the latest business tools",
  },
  {
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/eecf1f42-73ba-401c-8c60-52ca994d1646-H48g8IR1Hj6efwXlE5WJjSzU1YvijQ.jpeg",
    title: "Polished & Professional",
    description: "Experience working with well-presented and articulate assistants",
  },
  {
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Nevinne-BUSEPilwsGywUteScuoQdvoE4p82mr.jpeg",
    title: "Organized & Efficient",
    description: "Get help from detail-oriented professionals who deliver results",
  },
  {
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3670b30a-3f8a-4028-abd1-35b600ee40db-2HLSNqHabEZ3HAiItGa5RWl396Pagn.jpeg",
    title: "Versatile & Adaptable",
    description: "Find secretaries who can handle diverse business needs",
  },
]

export function Onboarding({ onComplete }: { onComplete: () => void }) {
  const [currentSlide, setCurrentSlide] = useState(0)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? prev : prev + 1))
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? prev : prev - 1))
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex-1 relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0"
          >
            <div className="relative h-full">
              <Image
                src={slides[currentSlide].image || "/placeholder.svg"}
                alt={slides[currentSlide].title}
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="absolute bottom-0 left-0 right-0 p-8 text-center">
          <motion.h2
            key={`title-${currentSlide}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-2xl font-bold mb-4"
          >
            {slides[currentSlide].title}
          </motion.h2>
          <motion.p
            key={`desc-${currentSlide}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-gray-300 mb-8"
          >
            {slides[currentSlide].description}
          </motion.p>

          <div className="flex justify-between items-center">
            <Button variant="ghost" onClick={prevSlide} disabled={currentSlide === 0} className="text-white">
              <ChevronLeft className="h-6 w-6" />
            </Button>

            <div className="flex space-x-2">
              {slides.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full ${currentSlide === index ? "bg-neon-pink" : "bg-gray-600"}`}
                />
              ))}
            </div>

            {currentSlide === slides.length - 1 ? (
              <Button neon onClick={onComplete}>
                Get Started
              </Button>
            ) : (
              <Button variant="ghost" onClick={nextSlide} className="text-white">
                <ChevronRight className="h-6 w-6" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

