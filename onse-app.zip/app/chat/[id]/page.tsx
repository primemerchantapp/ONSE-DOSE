"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "../../providers"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Send } from "lucide-react"
import Image from "next/image"

interface Message {
  id: string
  senderId: string
  text: string
  timestamp: string
  isRead: boolean
}

interface ChatPartner {
  id: string
  name: string
  photoURL: string
  isOnline: boolean
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [partner, setPartner] = useState<ChatPartner | null>(null)
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  const params = useParams()
  const router = useRouter()
  const { id } = params
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchChatData = async () => {
      if (!user || !id) return

      try {
        // This is a placeholder implementation
        // In a real app, you would fetch actual chat data from Firestore

        // Simulate loading delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Sample partner data
        setPartner({
          id: "user1",
          name: "Sarah Johnson",
          photoURL: "/placeholder.svg?height=100&width=100",
          isOnline: true,
        })

        // Sample messages
        setMessages([
          {
            id: "msg1",
            senderId: "user1",
            text: "Hello! I'm looking forward to our appointment.",
            timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
            isRead: true,
          },
          {
            id: "msg2",
            senderId: user.uid,
            text: "Hi Sarah! Yes, I'm excited to meet you too.",
            timestamp: new Date(Date.now() - 1000 * 60 * 55).toISOString(),
            isRead: true,
          },
          {
            id: "msg3",
            senderId: "user1",
            text: "Great! Do you have any specific tasks you'd like me to help with?",
            timestamp: new Date(Date.now() - 1000 * 60 * 50).toISOString(),
            isRead: true,
          },
          {
            id: "msg4",
            senderId: user.uid,
            text: "I need help organizing my schedule and managing emails.",
            timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
            isRead: true,
          },
          {
            id: "msg5",
            senderId: "user1",
            text: "Perfect! I'm very experienced with calendar management and email organization. I'll make sure everything is well-structured for you.",
            timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
            isRead: true,
          },
        ])
      } catch (error) {
        console.error("Error fetching chat data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchChatData()
  }, [id, user])

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim() || !user || !partner) return

    // Add message to the UI immediately for better UX
    const tempMessage: Message = {
      id: Date.now().toString(),
      senderId: user.uid,
      text: newMessage,
      timestamp: new Date().toISOString(),
      isRead: false,
    }

    setMessages([...messages, tempMessage])
    setNewMessage("")

    // In a real app, you would save the message to Firestore here
  }

  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="animate-spin h-8 w-8 border-t-2 border-neon-pink rounded-full"></div>
      </div>
    )
  }

  if (!partner) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <p>Chat not found</p>
      </div>
    )
  }

  return (
    <main className="flex flex-col h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10 border-b border-gray-800">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <div className="flex items-center">
          <div className="relative">
            <div className="w-10 h-10 rounded-full overflow-hidden">
              <Image
                src={partner.photoURL || "/placeholder.svg"}
                alt={partner.name}
                width={40}
                height={40}
                className="object-cover w-full h-full"
              />
            </div>
            {partner.isOnline && (
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-black"></div>
            )}
          </div>
          <div className="ml-3">
            <h2 className="font-semibold">{partner.name}</h2>
            <p className="text-xs text-gray-400">{partner.isOnline ? "Online" : "Offline"}</p>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => {
          const isOwnMessage = message.senderId === user?.uid

          return (
            <div key={message.id} className={`flex ${isOwnMessage ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                  isOwnMessage ? "bg-neon-pink text-white rounded-br-none" : "bg-gray-800 text-white rounded-bl-none"
                }`}
              >
                <p>{message.text}</p>
                <p className={`text-xs mt-1 ${isOwnMessage ? "text-white/70" : "text-gray-400"}`}>
                  {formatTime(message.timestamp)}
                </p>
              </div>
            </div>
          )
        })}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-800 flex items-center space-x-2">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message..."
          className="flex-1 bg-gray-900 border border-gray-700 rounded-full px-4 py-2 focus:outline-none focus:border-neon-pink"
        />
        <Button type="submit" neon className="rounded-full p-2 w-10 h-10 flex items-center justify-center">
          <Send size={18} />
        </Button>
      </form>
    </main>
  )
}

