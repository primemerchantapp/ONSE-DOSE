"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { doc, getDoc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../../providers"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Calendar, Clock, MapPin } from "lucide-react"
import Image from "next/image"

interface BookingDetails {
  id: string
  secretaryId: string
  secretaryName: string
  secretaryPhoto: string
  secretaryLocation: string
  date: string
  time: string
  duration: number
  totalAmount: number
  status: "pending" | "confirmed" | "completed" | "cancelled"
  createdAt: string
}

export default function BookingDetailsPage() {
  const [booking, setBooking] = useState<BookingDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [cancelling, setCancelling] = useState(false)
  const { user } = useAuth()
  const params = useParams()
  const router = useRouter()
  const { id } = params

  useEffect(() => {
    const fetchBookingDetails = async () => {
      if (!user || !id) return

      try {
        const bookingDoc = await getDoc(doc(db, "bookings", id as string))

        if (!bookingDoc.exists()) {
          router.push("/bookings")
          return
        }

        const bookingData = bookingDoc.data()

        // Check if this booking belongs to the current user
        if (bookingData.clientId !== user.uid) {
          router.push("/bookings")
          return
        }

        // Fetch secretary details
        const secretaryDoc = await getDoc(doc(db, "users", bookingData.secretaryId))
        const secretaryData = secretaryDoc.data()

        setBooking({
          id: bookingDoc.id,
          secretaryId: bookingData.secretaryId,
          secretaryName: secretaryData?.name || "Professional Secretary",
          secretaryPhoto: secretaryData?.photos?.[0] || "/placeholder.svg?height=100&width=100",
          secretaryLocation: secretaryData?.location || "Remote",
          date: bookingData.date,
          time: bookingData.time,
          duration: bookingData.duration,
          totalAmount: bookingData.totalAmount,
          status: bookingData.status,
          createdAt: bookingData.createdAt.toDate().toISOString(),
        })
      } catch (error) {
        console.error("Error fetching booking details:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchBookingDetails()
  }, [id, user, router])

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
    return new Date(dateString).toLocaleDateString("en-US", options)
  }

  const handleCancel = async () => {
    if (!booking) return

    setCancelling(true)

    try {
      await updateDoc(doc(db, "bookings", booking.id), {
        status: "cancelled",
      })

      // Update local state
      setBooking({
        ...booking,
        status: "cancelled",
      })
    } catch (error) {
      console.error("Error cancelling booking:", error)
    } finally {
      setCancelling(false)
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <div className="animate-spin h-8 w-8 border-t-2 border-neon-pink rounded-full"></div>
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <p>Booking not found</p>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Booking Details</h1>
      </header>

      <div className="p-4 space-y-6">
        <div className="bg-gray-900 rounded-xl overflow-hidden">
          <div className="p-4 flex items-center space-x-4">
            <div className="w-16 h-16 rounded-full overflow-hidden">
              <Image
                src={booking.secretaryPhoto || "/placeholder.svg"}
                alt={booking.secretaryName}
                width={64}
                height={64}
                className="object-cover w-full h-full"
              />
            </div>
            <div>
              <h2 className="text-lg font-semibold">{booking.secretaryName}</h2>
              <div className="flex items-center text-sm text-gray-400">
                <MapPin className="h-3 w-3 mr-1" />
                {booking.secretaryLocation}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-900 rounded-xl p-4 space-y-4">
          <h3 className="text-lg font-semibold">Booking Information</h3>

          <div className="space-y-2">
            <div className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-gray-400" />
              <div>
                <p className="text-sm text-gray-400">Date</p>
                <p>{formatDate(booking.date)}</p>
              </div>
            </div>

            <div className="flex items-center">
              <Clock className="h-5 w-5 mr-2 text-gray-400" />
              <div>
                <p className="text-sm text-gray-400">Time</p>
                <p>
                  {booking.time} ({booking.duration} hour{booking.duration > 1 ? "s" : ""})
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-4">
            <div className="flex justify-between">
              <span>Rate per hour</span>
              <span>{booking.totalAmount / booking.duration} credits</span>
            </div>
            <div className="flex justify-between">
              <span>Duration</span>
              <span>{booking.duration} hours</span>
            </div>
            <div className="border-t border-gray-800 my-2 pt-2 flex justify-between font-semibold">
              <span>Total</span>
              <span className="text-neon-pink">{booking.totalAmount} credits</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-900 rounded-xl p-4">
          <h3 className="text-lg font-semibold mb-2">Status</h3>
          <div className="flex items-center space-x-2">
            <div
              className={`w-3 h-3 rounded-full ${
                booking.status === "confirmed"
                  ? "bg-green-500"
                  : booking.status === "completed"
                    ? "bg-blue-500"
                    : booking.status === "cancelled"
                      ? "bg-red-500"
                      : "bg-yellow-500"
              }`}
            ></div>
            <span className="capitalize">{booking.status}</span>
          </div>
        </div>

        {booking.status === "pending" && (
          <Button variant="danger" fullWidth isLoading={cancelling} onClick={handleCancel}>
            Cancel Booking
          </Button>
        )}
      </div>
    </main>
  )
}

