"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { onAuthStateChanged, type User } from "firebase/auth"
import { doc, getDoc } from "firebase/firestore"
import { auth, db } from "@/lib/firebase"
import { registerServiceWorker } from "./sw"
import { Loader2 } from "lucide-react"
import { initializeNotifications } from "@/lib/notificationService"

type UserProfile = {
  usertype: string
  name?: string
  photos?: string[]
  interests?: string[]
  relationshipGoal?: string
  languages?: string[]
  location?: string
  description?: string
  rate?: number
  credits?: number
}

type AuthContextType = {
  user: User | null
  profile: UserProfile | null
  loading: boolean
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  refreshProfile: async () => {},
})

export const useAuth = () => useContext(AuthContext)

export function Providers({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchUserProfile = async (userId: string) => {
    try {
      const userDoc = await getDoc(doc(db, "users", userId))
      if (userDoc.exists()) {
        setProfile(userDoc.data() as UserProfile)
      }
    } catch (error) {
      console.error("Error fetching user profile:", error)
    }
  }

  const refreshProfile = async () => {
    if (user) {
      await fetchUserProfile(user.uid)
    }
  }

  useEffect(() => {
    // Register service worker for PWA functionality
    registerServiceWorker()

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser)

      if (currentUser) {
        await fetchUserProfile(currentUser.uid)
        await initializeNotifications(currentUser.uid) // Initialize notifications
      } else {
        setProfile(null)
      }

      setLoading(false)
    })

    return () => unsubscribe()
  }, []) // Removed unnecessary dependencies

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Loader2 className="h-8 w-8 animate-spin text-neon-pink" />
      </div>
    )
  }

  return <AuthContext.Provider value={{ user, profile, loading, refreshProfile }}>{children}</AuthContext.Provider>
}

