"use client"

import { useState, useEffect } from "react"
import { SplashScreen } from "./splash-screen"
import { Onboarding } from "./onboarding"
import { RoleSelection } from "./role-selection"

export default function Home() {
  const [showSplash, setShowSplash] = useState(true)
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState(false)

  useEffect(() => {
    // Check if user has seen onboarding before
    const seen = localStorage.getItem("hasSeenOnboarding") === "true"
    setHasSeenOnboarding(seen)
  }, [])

  const handleSplashComplete = () => {
    setShowSplash(false)
    // If user hasn't seen onboarding, show it now
    if (!hasSeenOnboarding) {
      setShowOnboarding(true)
    }
  }

  const handleOnboardingComplete = () => {
    setShowOnboarding(false)
    localStorage.setItem("hasSeenOnboarding", "true")
    setHasSeenOnboarding(true)
  }

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />
  }

  if (showOnboarding) {
    return <Onboarding onComplete={handleOnboardingComplete} />
  }

  return <RoleSelection />
}

