"use client"

import { useEffect, useState } from "react"
import { collection, query, where, orderBy, getDocs, doc, updateDoc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../providers"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ArrowLeft, CheckCircle, XCircle, User, DollarSign, Clock } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { sendNotification } from "@/lib/notificationService"

interface Payment {
  id: string
  userId: string
  userName?: string
  amount: number
  onsCredits: number
  paymentMethod: string
  status: "pending" | "confirmed" | "rejected"
  createdAt: Date
  screenshotURL: string
  note?: string
}

export default function AdminDashboardPage() {
  const [payments, setPayments] = useState<Payment[]>([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalUsers: 0,
    pendingPayments: 0,
    totalCredits: 0,
  })
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // Check if user is admin
    if (!user || user.email !== "admin@onse.vip") {
      router.push("/dashboard")
      return
    }

    const fetchAdminData = async () => {
      try {
        // Fetch pending payments
        const paymentsQuery = query(
          collection(db, "payments"),
          where("status", "==", "pending"),
          orderBy("createdAt", "desc"),
        )

        const paymentsSnapshot = await getDocs(paymentsQuery)
        const paymentsData: Payment[] = []

        // Get user names for each payment
        for (const paymentDoc of paymentsSnapshot.docs) {
          const paymentData = paymentDoc.data()
          const userDoc = await getDoc(doc(db, "users", paymentData.userId))
          const userData = userDoc.data()

          paymentsData.push({
            id: paymentDoc.id,
            userId: paymentData.userId,
            userName: userData?.name || "Unknown User",
            amount: paymentData.amount,
            onsCredits: paymentData.onsCredits,
            paymentMethod: paymentData.paymentMethod,
            status: paymentData.status,
            createdAt: paymentData.createdAt ? new Date(paymentData.createdAt.seconds * 1000) : new Date(),
            screenshotURL: paymentData.screenshotURL,
            note: paymentData.note,
          })
        }

        setPayments(paymentsData)

        // Get stats
        const usersSnapshot = await getDocs(collection(db, "users"))
        const pendingPaymentsSnapshot = await getDocs(
          query(collection(db, "payments"), where("status", "==", "pending")),
        )
        const confirmedPaymentsSnapshot = await getDocs(
          query(collection(db, "payments"), where("status", "==", "confirmed")),
        )

        let totalCredits = 0
        confirmedPaymentsSnapshot.forEach((doc) => {
          totalCredits += doc.data().onsCredits || 0
        })

        setStats({
          totalUsers: usersSnapshot.size,
          pendingPayments: pendingPaymentsSnapshot.size,
          totalCredits,
        })
      } catch (error) {
        console.error("Error fetching admin data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAdminData()
  }, [user, router])

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const handleApprovePayment = async (paymentId: string, userId: string, credits: number) => {
    try {
      // Update payment status
      await updateDoc(doc(db, "payments", paymentId), {
        status: "confirmed",
      })

      // Get current user credits
      const userDoc = await getDoc(doc(db, "users", userId))
      const userData = userDoc.data()
      const currentCredits = userData?.credits || 0

      // Add credits to user
      await updateDoc(doc(db, "users", userId), {
        credits: currentCredits + credits,
      })

      // Send notification to user
      await sendNotification(userId, "Payment Approved", `Your payment of ${credits} credits has been approved.`, {
        paymentId,
      })

      // Update local state
      setPayments(payments.filter((payment) => payment.id !== paymentId))
      setStats({
        ...stats,
        pendingPayments: stats.pendingPayments - 1,
        totalCredits: stats.totalCredits + credits,
      })
    } catch (error) {
      console.error("Error approving payment:", error)
    }
  }

  const handleRejectPayment = async (paymentId: string, userId: string) => {
    try {
      // Update payment status
      await updateDoc(doc(db, "payments", paymentId), {
        status: "rejected",
      })

      // Send notification to user
      await sendNotification(
        userId,
        "Payment Rejected",
        "Your payment has been rejected. Please contact support for more information.",
        { paymentId },
      )

      // Update local state
      setPayments(payments.filter((payment) => payment.id !== paymentId))
      setStats({
        ...stats,
        pendingPayments: stats.pendingPayments - 1,
      })
    } catch (error) {
      console.error("Error rejecting payment:", error)
    }
  }

  if (!user || user.email !== "admin@onse.vip") {
    return null // This will prevent the component from rendering for non-admin users
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.push("/dashboard")} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Admin Dashboard</h1>
      </header>

      <div className="p-4 space-y-6">
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gray-900 rounded-xl p-4 flex flex-col items-center">
            <User className="h-6 w-6 text-neon-pink mb-2" />
            <div className="text-2xl font-bold">{stats.totalUsers}</div>
            <div className="text-xs text-gray-400">Total Users</div>
          </div>

          <div className="bg-gray-900 rounded-xl p-4 flex flex-col items-center">
            <Clock className="h-6 w-6 text-yellow-500 mb-2" />
            <div className="text-2xl font-bold">{stats.pendingPayments}</div>
            <div className="text-xs text-gray-400">Pending Payments</div>
          </div>

          <div className="bg-gray-900 rounded-xl p-4 flex flex-col items-center">
            <DollarSign className="h-6 w-6 text-green-500 mb-2" />
            <div className="text-2xl font-bold">{stats.totalCredits}</div>
            <div className="text-xs text-gray-400">Total Credits</div>
          </div>
        </div>

        <h2 className="text-lg font-semibold">Pending Payments</h2>

        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin h-8 w-8 border-t-2 border-neon-pink rounded-full"></div>
          </div>
        ) : (
          <>
            {payments.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-400">No pending payments</p>
              </div>
            ) : (
              <div className="space-y-4">
                {payments.map((payment) => (
                  <div key={payment.id} className="bg-gray-900 rounded-xl overflow-hidden">
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <div className="font-semibold">{payment.onsCredits} credits</div>
                          <div className="text-sm text-gray-400">
                            {payment.userName} • {formatDate(payment.createdAt)}
                          </div>
                        </div>
                        <div className="px-3 py-1 rounded-full text-xs flex items-center gap-1 text-yellow-500 bg-yellow-500/10">
                          <Clock className="h-4 w-4" />
                          <span>Pending</span>
                        </div>
                      </div>

                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Amount</span>
                        <span>₱{payment.amount.toLocaleString()}</span>
                      </div>

                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Method</span>
                        <span>{payment.paymentMethod}</span>
                      </div>

                      {payment.note && (
                        <div className="mt-2 text-sm text-gray-400">
                          <div>Note:</div>
                          <div className="italic">{payment.note}</div>
                        </div>
                      )}
                    </div>

                    <div className="border-t border-gray-800">
                      <div className="p-2">
                        <div className="text-xs text-gray-500 mb-1">Payment Screenshot</div>
                        <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
                          <Image
                            src={payment.screenshotURL || "/placeholder.svg"}
                            alt="Payment screenshot"
                            layout="fill"
                            objectFit="cover"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="p-4 border-t border-gray-800 flex space-x-2">
                      <Button
                        onClick={() => handleRejectPayment(payment.id, payment.userId)}
                        variant="outline"
                        className="flex-1"
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Reject
                      </Button>
                      <Button
                        onClick={() => handleApprovePayment(payment.id, payment.userId, payment.onsCredits)}
                        neon
                        className="flex-1"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Approve
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

