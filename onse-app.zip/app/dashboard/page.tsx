"use client"

import { useEffect, useState } from "react"
import { collection, query, where, getDocs, limit } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../providers"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { Loader2, Star } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { AppHeader } from "@/components/app-header"
import ErrorBoundary from "@/components/error-boundary"

interface Secretary {
  id: string
  name: string
  location: string
  description: string
  rate: number
  photoURL: string
  rating?: number
}

export default function Dashboard() {
  const [secretaries, setSecretaries] = useState<Secretary[]>([])
  const [loading, setLoading] = useState(true)
  const { user, profile } = useAuth()

  useEffect(() => {
    const fetchSecretaries = async () => {
      if (!user) return

      try {
        const q = query(
          collection(db, "users"),
          where("usertype", "==", "secretary"),
          where("appName", "==", "onse"),
          limit(10),
        )

        const querySnapshot = await getDocs(q)
        const secretariesData: Secretary[] = []

        querySnapshot.forEach((doc) => {
          const data = doc.data()
          secretariesData.push({
            id: doc.id,
            name: data.name || "Professional Secretary",
            location: data.location || "Remote",
            description: data.description || "Professional secretary available for hire",
            rate: data.rate || 1000,
            photoURL: data.photos?.[0] || "/placeholder.svg?height=600&width=400",
            rating: data.rating || 4 + Math.random(),
          })
        })

        setSecretaries(secretariesData)
      } catch (error) {
        console.error("Error fetching secretaries:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchSecretaries()
  }, [user])

  return (
    <ErrorBoundary fallback={<div>Something went wrong. Please try again later.</div>}>
      <main className="min-h-screen bg-black text-white pb-20">
        <AppHeader showProfile={true} />

        <div className="p-4">
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-2">Welcome{profile?.name ? `, ${profile.name}` : ""}!</h2>
            <p className="text-gray-400">Find and book professional secretaries</p>
          </div>

          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-neon-pink" />
            </div>
          ) : (
            <div className="space-y-4">
              {secretaries.map((secretary) => (
                <div key={secretary.id} className="bg-gray-900 rounded-xl overflow-hidden">
                  <div className="relative aspect-[3/4] w-full">
                    <Image
                      src={secretary.photoURL || "/placeholder.svg"}
                      alt={secretary.name}
                      layout="fill"
                      objectFit="cover"
                      objectPosition="center top"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <h2 className="text-2xl font-bold">{secretary.name}</h2>
                      <div className="flex items-center text-sm mb-2">
                        <span className="mr-1">📍</span> {secretary.location}
                        <div className="ml-auto flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 mr-1" />
                          <span>{secretary.rating?.toFixed(1)}</span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-300 mb-2 line-clamp-2">{secretary.description}</p>
                      <p className="font-semibold text-neon-pink mb-2">{secretary.rate} credits/hr</p>
                      <div className="flex space-x-2">
                        <Link href={`/secretary/${secretary.id}`} className="flex-1">
                          <Button variant="outline" fullWidth>
                            View Profile
                          </Button>
                        </Link>
                        <Link href={`/booking/${secretary.id}`} className="flex-1">
                          <Button neon fullWidth>
                            Book Now
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <BottomNav />
      </main>
    </ErrorBoundary>
  )
}

