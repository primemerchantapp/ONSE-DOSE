"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { doc, updateDoc } from "firebase/firestore"
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"
import { signOut } from "firebase/auth"
import { db, storage, auth } from "@/lib/firebase"
import { useAuth } from "../providers"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ArrowRight, Camera, LogOut, Pencil } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { collection, query, where, getDocs } from "firebase/firestore"

export default function ProfilePage() {
  const [uploading, setUploading] = useState(false)
  const [pendingTransactions, setPendingTransactions] = useState(0)
  const { user, profile, refreshProfile } = useAuth()
  const router = useRouter()

  useEffect(() => {
    const fetchPendingTransactions = async () => {
      if (!user) return

      try {
        const q = query(collection(db, "payments"), where("userId", "==", user.uid), where("status", "==", "pending"))

        const querySnapshot = await getDocs(q)
        setPendingTransactions(querySnapshot.size)
      } catch (error) {
        console.error("Error fetching pending transactions:", error)
      }
    }

    fetchPendingTransactions()
  }, [user])

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files.length || !user) return

    setUploading(true)

    try {
      const file = e.target.files[0]
      const storageRef = ref(storage, `users/${user.uid}/photos/${Date.now()}_${file.name}`)

      await uploadBytes(storageRef, file)
      const photoURL = await getDownloadURL(storageRef)

      // Get current photos array or initialize empty array
      const currentPhotos = profile?.photos || []

      // Update user document with the new photo URL
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        photos: [photoURL, ...currentPhotos],
      })

      // Refresh profile data
      await refreshProfile()
    } catch (error) {
      console.error("Error uploading photo:", error)
    } finally {
      setUploading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await signOut(auth)
      router.push("/")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <h1 className="text-2xl font-bold">Profile</h1>
      </header>

      <div className="p-4 space-y-6">
        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="w-24 h-24 rounded-full overflow-hidden bg-gray-800">
              {profile?.photos && profile.photos[0] ? (
                <Image
                  src={profile.photos[0] || "/placeholder.svg"}
                  alt="Profile"
                  width={96}
                  height={96}
                  className="object-cover w-full h-full"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400">
                  {profile?.name?.[0] || user?.email?.[0] || "U"}
                </div>
              )}
            </div>
            <label
              htmlFor="photo-upload"
              className="absolute bottom-0 right-0 bg-neon-pink rounded-full p-2 cursor-pointer"
            >
              <Camera size={16} className="text-white" />
              <input
                id="photo-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
                disabled={uploading}
              />
            </label>
          </div>
          <h2 className="mt-4 text-xl font-bold">{profile?.name || user?.email}</h2>
          <p className="text-gray-400">{profile?.usertype === "secretary" ? "Secretary" : "Boss"}</p>
          <div className="mt-4 text-center">
            <div className="text-sm text-gray-400">Credits Balance</div>
            <div className="text-2xl font-bold text-neon-pink">{profile?.credits || 0} credits</div>
            <div className="flex gap-2 mt-2">
              <Button onClick={() => router.push("/credits")} variant="outline" size="sm">
                Add Credits
              </Button>
              <Button onClick={() => router.push("/transactions")} variant="outline" size="sm" className="relative">
                Transactions
                {pendingTransactions > 0 && (
                  <span className="absolute -top-2 -right-2 bg-neon-pink text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {pendingTransactions}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-gray-900 rounded-xl overflow-hidden">
            <Link href="/profile/edit" className="p-4 flex justify-between items-center">
              <div className="flex items-center">
                <Pencil size={20} className="mr-3 text-gray-400" />
                <span>Edit Profile</span>
              </div>
              <ArrowRight size={18} className="text-gray-400" />
            </Link>
          </div>

          {profile?.usertype === "secretary" && (
            <div className="bg-gray-900 rounded-xl overflow-hidden">
              <Link href="/profile/availability" className="p-4 flex justify-between items-center">
                <div className="flex items-center">
                  <Camera size={20} className="mr-3 text-gray-400" />
                  <span>Manage Availability</span>
                </div>
                <ArrowRight size={18} className="text-gray-400" />
              </Link>
            </div>
          )}

          <div className="bg-gray-900 rounded-xl overflow-hidden">
            <Link href="/profile/photos" className="p-4 flex justify-between items-center">
              <div className="flex items-center">
                <Camera size={20} className="mr-3 text-gray-400" />
                <span>Manage Photos</span>
              </div>
              <ArrowRight size={18} className="text-gray-400" />
            </Link>
          </div>

          <Button variant="outline" fullWidth onClick={handleLogout} className="mt-8">
            <LogOut size={18} className="mr-2" />
            Sign Out
          </Button>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

