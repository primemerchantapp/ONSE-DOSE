"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { doc, updateDoc, arrayUnion, arrayRemove, getDoc } from "firebase/firestore"
import { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage"
import { db, storage } from "@/lib/firebase"
import { useAuth } from "../../providers"
import { ArrowLeft, Plus, X, Lock, Unlock } from "lucide-react"
import Image from "next/image"

export default function ManagePhotosPage() {
  const [photos, setPhotos] = useState<string[]>([])
  const [privatePhotos, setPrivatePhotos] = useState<string[]>([])
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [isPublic, setIsPublic] = useState(true)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()
  const { user, refreshProfile } = useAuth()

  useEffect(() => {
    if (user) {
      const fetchUserMedia = async () => {
        const userDoc = await getDoc(doc(db, "users", user.uid))
        if (userDoc.exists()) {
          const userData = userDoc.data()
          setPhotos(userData.photos || [])
          setPrivatePhotos(userData.privatePhotos || [])
          setVideoUrl(userData.videoUrl || null)
          setIsPublic(userData.isPublic !== false)
        }
      }
      fetchUserMedia()
    }
  }, [user])

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, isPrivate = false) => {
    if (!e.target.files || !e.target.files.length || !user) return

    setUploading(true)

    try {
      const file = e.target.files[0]
      const storageRef = ref(storage, `users/${user.uid}/photos/${Date.now()}_${file.name}`)

      await uploadBytes(storageRef, file)
      const photoURL = await getDownloadURL(storageRef)

      const userRef = doc(db, "users", user.uid)
      if (isPrivate) {
        await updateDoc(userRef, {
          privatePhotos: arrayUnion(photoURL),
        })
        setPrivatePhotos([...privatePhotos, photoURL])
      } else {
        await updateDoc(userRef, {
          photos: arrayUnion(photoURL),
        })
        setPhotos([...photos, photoURL])
      }

      await refreshProfile()
    } catch (error) {
      console.error("Error uploading photo:", error)
    } finally {
      setUploading(false)
    }
  }

  const handleVideoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files.length || !user) return

    setUploading(true)

    try {
      const file = e.target.files[0]
      const storageRef = ref(storage, `users/${user.uid}/video/${Date.now()}_${file.name}`)
      await uploadBytes(storageRef, file)
      const videoURL = await getDownloadURL(storageRef)
      setVideoUrl(videoURL)

      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, { videoUrl: videoURL })
      await refreshProfile()
    } catch (error) {
      console.error("Error uploading video:", error)
    } finally {
      setUploading(false)
    }
  }

  const removePhoto = async (photoUrl: string, isPrivate = false) => {
    if (!user) return

    try {
      const newPhotos = isPrivate
        ? privatePhotos.filter((url) => url !== photoUrl)
        : photos.filter((url) => url !== photoUrl)

      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        [isPrivate ? "privatePhotos" : "photos"]: arrayRemove(photoUrl),
      })

      if (isPrivate) {
        setPrivatePhotos(newPhotos)
      } else {
        setPhotos(newPhotos)
      }

      const photoRef = ref(storage, photoUrl)
      await deleteObject(photoRef)

      await refreshProfile()
    } catch (error) {
      console.error("Error removing photo:", error)
    }
  }

  const togglePhotoPrivacy = async (photoUrl: string, currentlyPrivate: boolean) => {
    if (!user) return

    try {
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        [currentlyPrivate ? "privatePhotos" : "photos"]: arrayRemove(photoUrl),
        [currentlyPrivate ? "photos" : "privatePhotos"]: arrayUnion(photoUrl),
      })

      if (currentlyPrivate) {
        setPrivatePhotos(privatePhotos.filter((url) => url !== photoUrl))
        setPhotos([...photos, photoUrl])
      } else {
        setPhotos(photos.filter((url) => url !== photoUrl))
        setPrivatePhotos([...privatePhotos, photoUrl])
      }

      await refreshProfile()
    } catch (error) {
      console.error("Error toggling photo privacy:", error)
    }
  }

  const removeVideo = async () => {
    if (!user || !videoUrl) return

    try {
      setVideoUrl(null)

      // Update user document to remove the video URL
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        videoUrl: null,
      })

      // Delete the video from storage
      const videoRef = ref(storage, videoUrl)
      await deleteObject(videoRef)

      await refreshProfile()
    } catch (error) {
      console.error("Error removing video:", error)
    }
  }

  const togglePublicStatus = async () => {
    if (!user) return

    try {
      const newStatus = !isPublic
      setIsPublic(newStatus)

      // Update user document with the new public status
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        isPublic: newStatus,
      })

      await refreshProfile()
    } catch (error) {
      console.error("Error updating public status:", error)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Manage Photos & Video</h1>
      </header>

      <div className="p-4 space-y-6">
        <div>
          <h2 className="text-lg font-semibold mb-2">Public Photos</h2>
          <div className="grid grid-cols-3 gap-4">
            {photos.map((photo, index) => (
              <div key={index} className="relative aspect-square rounded-xl overflow-hidden">
                <Image
                  src={photo || "/placeholder.svg"}
                  alt={`Profile photo ${index + 1}`}
                  layout="fill"
                  objectFit="cover"
                />
                <button
                  onClick={() => removePhoto(photo)}
                  className="absolute top-2 right-2 bg-black/70 rounded-full p-1"
                >
                  <X size={16} className="text-white" />
                </button>
                <button
                  onClick={() => togglePhotoPrivacy(photo, false)}
                  className="absolute bottom-2 right-2 bg-black/70 rounded-full p-1"
                >
                  <Lock size={16} className="text-white" />
                </button>
              </div>
            ))}
            {photos.length < 6 && (
              <div
                className="aspect-square rounded-xl border border-dashed border-gray-700 flex items-center justify-center cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <Plus size={24} className="text-gray-400" />
              </div>
            )}
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => handleFileChange(e)}
            accept="image/*"
            className="hidden"
          />
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-2">Private Photos</h2>
          <div className="grid grid-cols-3 gap-4">
            {privatePhotos.map((photo, index) => (
              <div key={index} className="relative aspect-square rounded-xl overflow-hidden">
                <Image
                  src={photo || "/placeholder.svg"}
                  alt={`Private photo ${index + 1}`}
                  layout="fill"
                  objectFit="cover"
                />
                <button
                  onClick={() => removePhoto(photo, true)}
                  className="absolute top-2 right-2 bg-black/70 rounded-full p-1"
                >
                  <X size={16} className="text-white" />
                </button>
                <button
                  onClick={() => togglePhotoPrivacy(photo, true)}
                  className="absolute bottom-2 right-2 bg-black/70 rounded-full p-1"
                >
                  <Unlock size={16} className="text-white" />
                </button>
              </div>
            ))}
            {privatePhotos.length < 6 && (
              <div
                className="aspect-square rounded-xl border border-dashed border-gray-700 flex items-center justify-center cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <Plus size={24} className="text-gray-400" />
              </div>
            )}
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => handleFileChange(e, true)}
            accept="image/*"
            className="hidden"
          />
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-2">Video (15 seconds max)</h2>
          {videoUrl ? (
            <div className="relative aspect-video rounded-xl overflow-hidden">
              <video src={videoUrl} controls className="w-full h-full object-cover" />
              <button onClick={removeVideo} className="absolute top-2 right-2 bg-black/70 rounded-full p-1">
                <X size={16} className="text-white" />
              </button>
            </div>
          ) : (
            <div
              className="aspect-video rounded-xl border border-dashed border-gray-700 flex items-center justify-center cursor-pointer"
              onClick={() => videoInputRef.current?.click()}
            >
              <Plus size={24} className="text-gray-400" />
              <span className="ml-2">Add Video</span>
            </div>
          )}
          <input type="file" ref={videoInputRef} onChange={handleVideoChange} accept="video/*" className="hidden" />
        </div>

        {uploading && (
          <div className="text-center">
            <p>Uploading...</p>
          </div>
        )}
      </div>
    </main>
  )
}

