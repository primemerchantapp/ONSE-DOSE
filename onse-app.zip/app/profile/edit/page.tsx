"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { doc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../../providers"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function EditProfilePage() {
  const [name, setName] = useState("")
  const [location, setLocation] = useState("")
  const [description, setDescription] = useState("")
  const [interests, setInterests] = useState<string[]>([])
  const [languages, setLanguages] = useState<string[]>([])
  const [rate, setRate] = useState<number>(0)
  const [newInterest, setNewInterest] = useState("")
  const [newLanguage, setNewLanguage] = useState("")
  const [saving, setSaving] = useState(false)
  const { user, profile, refreshProfile } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (profile) {
      setName(profile.name || "")
      setLocation(profile.location || "")
      setDescription(profile.description || "")
      setInterests(profile.interests || [])
      setLanguages(profile.languages || [])
      setRate(profile.rate || 1000)
    }
  }, [profile])

  const handleSave = async () => {
    if (!user) return

    setSaving(true)

    try {
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        name,
        location,
        description,
        interests,
        languages,
        rate: Number(rate),
      })

      await refreshProfile()
      router.back()
    } catch (error) {
      console.error("Error updating profile:", error)
    } finally {
      setSaving(false)
    }
  }

  const addInterest = () => {
    if (newInterest && !interests.includes(newInterest)) {
      setInterests([...interests, newInterest])
      setNewInterest("")
    }
  }

  const removeInterest = (interest: string) => {
    setInterests(interests.filter((i) => i !== interest))
  }

  const addLanguage = () => {
    if (newLanguage && !languages.includes(newLanguage)) {
      setLanguages([...languages, newLanguage])
      setNewLanguage("")
    }
  }

  const removeLanguage = (language: string) => {
    setLanguages(languages.filter((l) => l !== language))
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Edit Profile</h1>
      </header>

      <div className="p-4 space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
            placeholder="Your name"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Location</label>
          <input
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
            placeholder="Your location"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">About</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
            placeholder="Tell us about yourself"
            rows={4}
          />
        </div>

        {profile?.usertype === "secretary" && (
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Hourly Rate (ONS)</label>
            <input
              type="number"
              value={rate}
              onChange={(e) => setRate(Number(e.target.value))}
              className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
              placeholder="Your hourly rate"
              min={0}
            />
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Interests</label>
          <div className="flex flex-wrap gap-2 mb-2">
            {interests.map((interest, index) => (
              <div key={index} className="px-3 py-1 bg-gray-800 rounded-full text-sm flex items-center">
                {interest}
                <button onClick={() => removeInterest(interest)} className="ml-2 text-gray-400">
                  &times;
                </button>
              </div>
            ))}
          </div>
          <div className="flex">
            <input
              type="text"
              value={newInterest}
              onChange={(e) => setNewInterest(e.target.value)}
              className="flex-1 px-3 py-2 bg-gray-900 border border-gray-700 rounded-l-lg text-white"
              placeholder="Add an interest"
            />
            <button onClick={addInterest} className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-r-lg">
              Add
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Languages</label>
          <div className="flex flex-wrap gap-2 mb-2">
            {languages.map((language, index) => (
              <div key={index} className="px-3 py-1 bg-gray-800 rounded-full text-sm flex items-center">
                {language}
                <button onClick={() => removeLanguage(language)} className="ml-2 text-gray-400">
                  &times;
                </button>
              </div>
            ))}
          </div>
          <div className="flex">
            <input
              type="text"
              value={newLanguage}
              onChange={(e) => setNewLanguage(e.target.value)}
              className="flex-1 px-3 py-2 bg-gray-900 border border-gray-700 rounded-l-lg text-white"
              placeholder="Add a language"
            />
            <button onClick={addLanguage} className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-r-lg">
              Add
            </button>
          </div>
        </div>

        <Button neon fullWidth onClick={handleSave} isLoading={saving} className="mt-8">
          Save Changes
        </Button>
      </div>
    </main>
  )
}

