"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { doc, updateDoc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../../providers"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Check, Clock, Calendar } from "lucide-react"

const DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

const TIME_SLOTS = [
  "09:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "01:00 PM",
  "02:00 PM",
  "03:00 PM",
  "04:00 PM",
  "05:00 PM",
  "06:00 PM",
  "07:00 PM",
  "08:00 PM",
]

export default function AvailabilityPage() {
  const [availableDays, setAvailableDays] = useState<string[]>([])
  const [availableTimeSlots, setAvailableTimeSlots] = useState<string[]>([])
  const [unavailableDates, setUnavailableDates] = useState<string[]>([])
  const [newUnavailableDate, setNewUnavailableDate] = useState("")
  const [saving, setSaving] = useState(false)
  const { user, profile, refreshProfile } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // Redirect if not a secretary
    if (profile && profile.usertype !== "secretary") {
      router.push("/profile")
      return
    }

    const fetchAvailability = async () => {
      if (!user) return

      try {
        const userDoc = await getDoc(doc(db, "users", user.uid))
        if (userDoc.exists()) {
          const userData = userDoc.data()
          setAvailableDays(userData.availableDays || ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"])
          setAvailableTimeSlots(userData.availableTimeSlots || TIME_SLOTS.slice(0, 8)) // Default to first 8 time slots
          setUnavailableDates(userData.unavailableDates || [])
        }
      } catch (error) {
        console.error("Error fetching availability:", error)
      }
    }

    fetchAvailability()
  }, [user, profile, router])

  const handleSave = async () => {
    if (!user) return

    setSaving(true)

    try {
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        availableDays,
        availableTimeSlots,
        unavailableDates,
      })

      await refreshProfile()
      router.back()
    } catch (error) {
      console.error("Error updating availability:", error)
    } finally {
      setSaving(false)
    }
  }

  const toggleDay = (day: string) => {
    if (availableDays.includes(day)) {
      setAvailableDays(availableDays.filter((d) => d !== day))
    } else {
      setAvailableDays([...availableDays, day])
    }
  }

  const toggleTimeSlot = (timeSlot: string) => {
    if (availableTimeSlots.includes(timeSlot)) {
      setAvailableTimeSlots(availableTimeSlots.filter((t) => t !== timeSlot))
    } else {
      setAvailableTimeSlots([...availableTimeSlots, timeSlot])
    }
  }

  const addUnavailableDate = () => {
    if (newUnavailableDate && !unavailableDates.includes(newUnavailableDate)) {
      setUnavailableDates([...unavailableDates, newUnavailableDate])
      setNewUnavailableDate("")
    }
  }

  const removeUnavailableDate = (date: string) => {
    setUnavailableDates(unavailableDates.filter((d) => d !== date))
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Manage Availability</h1>
      </header>

      <div className="p-4 space-y-6">
        <div>
          <h2 className="text-lg font-semibold mb-2 flex items-center">
            <Calendar className="mr-2 h-5 w-5 text-neon-pink" />
            Available Days
          </h2>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
            {DAYS_OF_WEEK.map((day) => (
              <div
                key={day}
                className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between ${
                  availableDays.includes(day)
                    ? "border-neon-pink bg-neon-pink/10"
                    : "border-gray-700 hover:border-gray-600"
                }`}
                onClick={() => toggleDay(day)}
              >
                <span>{day}</span>
                {availableDays.includes(day) && <Check size={16} className="text-neon-pink" />}
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-2 flex items-center">
            <Clock className="mr-2 h-5 w-5 text-neon-pink" />
            Available Time Slots
          </h2>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
            {TIME_SLOTS.map((timeSlot) => (
              <div
                key={timeSlot}
                className={`p-2 rounded-xl border text-center cursor-pointer text-sm ${
                  availableTimeSlots.includes(timeSlot)
                    ? "border-neon-pink bg-neon-pink/10"
                    : "border-gray-700 hover:border-gray-600"
                }`}
                onClick={() => toggleTimeSlot(timeSlot)}
              >
                {timeSlot}
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-semibold mb-2">Unavailable Dates</h2>
          <div className="flex mb-2">
            <input
              type="date"
              value={newUnavailableDate}
              onChange={(e) => setNewUnavailableDate(e.target.value)}
              min={new Date().toISOString().split("T")[0]}
              className="flex-1 px-3 py-2 bg-gray-900 border border-gray-700 rounded-l-lg text-white"
            />
            <button
              onClick={addUnavailableDate}
              className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-r-lg"
              disabled={!newUnavailableDate}
            >
              Add
            </button>
          </div>

          {unavailableDates.length > 0 ? (
            <div className="space-y-2">
              {unavailableDates.map((date) => (
                <div key={date} className="flex justify-between items-center p-3 bg-gray-900 rounded-lg">
                  <span>
                    {new Date(date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                  </span>
                  <button onClick={() => removeUnavailableDate(date)} className="text-red-500">
                    Remove
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-sm">No unavailable dates set</p>
          )}
        </div>

        <Button neon fullWidth onClick={handleSave} isLoading={saving} className="mt-8">
          Save Availability
        </Button>
      </div>
    </main>
  )
}

