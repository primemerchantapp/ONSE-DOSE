"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"
import { doc, updateDoc } from "firebase/firestore"
import { storage, db } from "@/lib/firebase"
import Image from "next/image"
import { ArrowLeft, Plus, X } from "lucide-react"
import { useAuth } from "../providers"
import { Button } from "@/components/ui/button"

export default function ProfileSetup() {
  const [photos, setPhotos] = useState<string[]>([])
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()
  const { user, refreshProfile } = useAuth()

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files.length || !user) return

    setUploading(true)

    try {
      const file = e.target.files[0]
      const storageRef = ref(storage, `users/${user.uid}/photos/${Date.now()}_${file.name}`)

      await uploadBytes(storageRef, file)
      const photoURL = await getDownloadURL(storageRef)

      setPhotos([...photos, photoURL])

      // Update user document with the photo URL
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        photos: [...photos, photoURL],
      })
    } catch (error) {
      console.error("Error uploading photo:", error)
    } finally {
      setUploading(false)
    }
  }

  const removePhoto = async (index: number) => {
    if (!user) return

    const newPhotos = [...photos]
    newPhotos.splice(index, 1)
    setPhotos(newPhotos)

    // Update user document with the updated photos array
    try {
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        photos: newPhotos,
      })
    } catch (error) {
      console.error("Error updating photos:", error)
    }
  }

  const handleNext = async () => {
    if (photos.length >= 1 && user) {
      try {
        // Refresh profile data before navigating
        await refreshProfile()
        router.push("/profile-details")
      } catch (error) {
        console.error("Error refreshing profile:", error)
      }
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="p-4">
        <button onClick={() => router.back()} className="text-white">
          <ArrowLeft size={24} />
        </button>
      </div>

      <div className="px-6 py-4">
        <h1 className="text-3xl font-bold neon-text">Add your photos</h1>
        <p className="text-gray-400 mt-2">
          Upload at least 1 photo to continue. Add more to make your profile stand out.
        </p>

        <div className="mt-8 grid grid-cols-3 gap-4">
          {photos.map((photo, index) => (
            <div
              key={index}
              className="relative aspect-square rounded-xl overflow-hidden border border-dashed border-gray-700"
            >
              <Image
                src={photo || "/placeholder.svg"}
                alt={`Profile photo ${index + 1}`}
                fill
                className="object-cover"
              />
              <button
                onClick={() => removePhoto(index)}
                className="absolute top-2 right-2 bg-black/70 rounded-full p-1"
              >
                <X size={16} className="text-white" />
              </button>
            </div>
          ))}

          {Array.from({ length: 6 - photos.length }).map((_, index) => (
            <div
              key={`empty-${index}`}
              className="aspect-square rounded-xl border border-dashed border-gray-700 flex items-center justify-center cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="bg-neon-pink rounded-full p-2">
                <Plus size={24} className="text-white" />
              </div>
            </div>
          ))}
        </div>

        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />

        <div className="mt-8">
          <Button neon fullWidth onClick={handleNext} disabled={photos.length < 1 || uploading} isLoading={uploading}>
            {uploading ? "Uploading..." : "Next"}
          </Button>
        </div>
      </div>
    </main>
  )
}

