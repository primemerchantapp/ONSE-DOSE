"use client"

import { useEffect, useState } from "react"
import { collection, query, where, getDocs, limit } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../providers"
import { BottomNav } from "@/components/bottom-nav"
import { Loader2, MessageCircle } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { AppHeader } from "@/components/app-header"

interface Secretary {
  id: string
  name: string
  photoURL: string
  lastMessage?: string
  lastMessageTime?: string
}

export default function MessagesPage() {
  const [secretaries, setSecretaries] = useState<Secretary[]>([])
  const [loading, setLoading] = useState(true)
  const { user, profile } = useAuth()

  useEffect(() => {
    const fetchSecretaries = async () => {
      if (!user) return

      try {
        const q = query(
          collection(db, "users"),
          where("usertype", "==", "secretary"),
          where("appName", "==", "onse"),
          limit(20),
        )

        const querySnapshot = await getDocs(q)
        const secretariesData: Secretary[] = []

        querySnapshot.forEach((doc) => {
          const data = doc.data()
          secretariesData.push({
            id: doc.id,
            name: data.name || "Professional Secretary",
            photoURL: data.photos?.[0] || "/placeholder.svg?height=100&width=100",
          })
        })

        setSecretaries(secretariesData)
      } catch (error) {
        console.error("Error fetching secretaries:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchSecretaries()
  }, [user])

  const handleMessageClick = (secretaryId: string) => {
    // Implement credit check and deduction here
    console.log(`Attempting to message secretary ${secretaryId}`)
    // If successful, navigate to chat page
    // router.push(`/chat/${secretaryId}`)
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <AppHeader title="Messages" showProfile={true} />

      <div className="p-4">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-neon-pink" />
          </div>
        ) : (
          <div className="space-y-4">
            {secretaries.map((secretary) => (
              <div key={secretary.id} className="flex items-center space-x-4 bg-gray-900 p-4 rounded-xl">
                <Image
                  src={secretary.photoURL || "/placeholder.svg"}
                  alt={secretary.name}
                  width={60}
                  height={60}
                  className="rounded-full"
                />
                <div className="flex-1">
                  <h3 className="font-semibold">{secretary.name}</h3>
                  {secretary.lastMessage && <p className="text-sm text-gray-400 truncate">{secretary.lastMessage}</p>}
                </div>
                <Button
                  onClick={() => handleMessageClick(secretary.id)}
                  variant="outline"
                  size="sm"
                  className="whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Message Me
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

