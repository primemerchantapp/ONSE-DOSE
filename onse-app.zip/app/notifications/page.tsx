"use client"

import { useEffect, useState } from "react"
import { collection, query, where, getDocs, updateDoc, doc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "../providers"
import { BottomNav } from "@/components/bottom-nav"
import { Bell, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

interface Notification {
  id: string
  title: string
  body: string
  timestamp: Date
  read: boolean
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    const fetchNotifications = async () => {
      if (!user) return

      try {
        const q = query(collection(db, "notifications"), where("userId", "==", user.uid))

        const querySnapshot = await getDocs(q)
        const notificationsData: Notification[] = []

        querySnapshot.forEach((doc) => {
          const data = doc.data()
          notificationsData.push({
            id: doc.id,
            title: data.title,
            body: data.body,
            timestamp: data.timestamp.toDate(),
            read: data.read,
          })
        })

        // Sort notifications by timestamp (most recent first)
        notificationsData.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())

        setNotifications(notificationsData)
      } catch (error) {
        console.error("Error fetching notifications:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchNotifications()
  }, [user])

  const markAsRead = async (notificationId: string) => {
    try {
      await updateDoc(doc(db, "notifications", notificationId), {
        read: true,
      })
      setNotifications(notifications.map((n) => (n.id === notificationId ? { ...n, read: true } : n)))
    } catch (error) {
      console.error("Error marking notification as read:", error)
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleString()
  }

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Notifications</h1>
      </header>

      <div className="p-4">
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin h-8 w-8 border-t-2 border-neon-pink rounded-full"></div>
          </div>
        ) : (
          <>
            {notifications.length === 0 ? (
              <div className="text-center py-8">
                <Bell size={48} className="mx-auto text-gray-600 mb-4" />
                <p className="text-gray-400">No notifications yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`bg-gray-900 rounded-xl p-4 ${notification.read ? "opacity-60" : ""}`}
                    onClick={() => !notification.read && markAsRead(notification.id)}
                  >
                    <h2 className="font-semibold">{notification.title}</h2>
                    <p className="text-sm text-gray-400 mt-1">{notification.body}</p>
                    <p className="text-xs text-gray-500 mt-2">{formatDate(notification.timestamp)}</p>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

