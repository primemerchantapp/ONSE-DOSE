"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { doc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { ArrowLeft } from "lucide-react"
import { useAuth } from "../providers"
import { Button } from "@/components/ui/button"

export default function ProfileDetails() {
  const [name, setName] = useState("")
  const [location, setLocation] = useState("")
  const [description, setDescription] = useState("")
  const [interests, setInterests] = useState<string[]>([])
  const [languages, setLanguages] = useState<string[]>([])
  const [saving, setSaving] = useState(false)
  const router = useRouter()
  const { user, profile, refreshProfile } = useAuth()

  useEffect(() => {
    if (profile) {
      setName(profile.name || "")
      setLocation(profile.location || "")
      setDescription(profile.description || "")
      setInterests(profile.interests || [])
      setLanguages(profile.languages || [])
    }
  }, [profile])

  const handleSave = async () => {
    if (!user) return

    setSaving(true)

    try {
      const userRef = doc(db, "users", user.uid)
      await updateDoc(userRef, {
        name,
        location,
        description,
        interests,
        languages,
        profileCompleted: true,
      })

      await refreshProfile()
      router.push("/dashboard")
    } catch (error) {
      console.error("Error saving profile details:", error)
    } finally {
      setSaving(false)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="p-4">
        <button onClick={() => router.back()} className="text-white">
          <ArrowLeft size={24} />
        </button>
      </div>

      <div className="px-6 py-4">
        <h1 className="text-2xl font-bold neon-text">Complete Your Profile</h1>

        <div className="mt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
              placeholder="Your name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
              placeholder="Your location"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">About</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
              placeholder="Tell us about yourself"
              rows={4}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Interests</label>
            <div className="flex flex-wrap gap-2">
              {["Photography", "Travel", "Reading", "Cooking", "Sports", "Music", "Art", "Technology"].map(
                (interest) => (
                  <div
                    key={interest}
                    className={`px-3 py-1 rounded-full text-sm cursor-pointer ${
                      interests.includes(interest) ? "bg-neon-pink text-white" : "bg-gray-800 text-gray-300"
                    }`}
                    onClick={() => {
                      if (interests.includes(interest)) {
                        setInterests(interests.filter((i) => i !== interest))
                      } else {
                        setInterests([...interests, interest])
                      }
                    }}
                  >
                    {interest}
                  </div>
                ),
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1">Languages</label>
            <div className="flex flex-wrap gap-2">
              {["English", "Spanish", "French", "German", "Chinese", "Japanese", "Korean", "Russian"].map(
                (language) => (
                  <div
                    key={language}
                    className={`px-3 py-1 rounded-full text-sm cursor-pointer ${
                      languages.includes(language) ? "bg-neon-purple text-white" : "bg-gray-800 text-gray-300"
                    }`}
                    onClick={() => {
                      if (languages.includes(language)) {
                        setLanguages(languages.filter((l) => l !== language))
                      } else {
                        setLanguages([...languages, language])
                      }
                    }}
                  >
                    {language}
                  </div>
                ),
              )}
            </div>
          </div>
        </div>

        <div className="mt-8">
          <Button neon fullWidth onClick={handleSave} disabled={!name || saving} isLoading={saving}>
            Complete Profile
          </Button>
        </div>
      </div>
    </main>
  )
}

