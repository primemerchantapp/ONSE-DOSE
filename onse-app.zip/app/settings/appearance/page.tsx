"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function AppearancePage() {
  const router = useRouter()
  const [darkMode, setDarkMode] = useState(true)

  const handleSave = () => {
    // Implement save functionality
    console.log("Saving appearance settings:", { darkMode })
    router.back()
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Appearance</h1>
      </header>

      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <span>Dark Mode</span>
          <input
            type="checkbox"
            checked={darkMode}
            onChange={(e) => setDarkMode(e.target.checked)}
            className="toggle"
          />
        </div>

        <Button onClick={handleSave} neon fullWidth className="mt-6">
          Save Changes
        </Button>
      </div>
    </main>
  )
}

