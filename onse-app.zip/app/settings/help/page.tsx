"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"

export default function HelpSupportPage() {
  const router = useRouter()

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Help & Support</h1>
      </header>

      <div className="p-4 space-y-4">
        <h2 className="text-lg font-semibold">Frequently Asked Questions</h2>
        <ul className="space-y-2">
          <li>
            <h3 className="font-medium">How do I book a secretary?</h3>
            <p className="text-gray-400">Navigate to the dashboard, select a secretary, and click "Book Now".</p>
          </li>
          <li>
            <h3 className="font-medium">How can I become a secretary on the platform?</h3>
            <p className="text-gray-400">
              Sign up as a secretary and complete your profile with relevant skills and experience.
            </p>
          </li>
        </ul>

        <h2 className="text-lg font-semibold mt-6">Contact Support</h2>
        <p className="text-gray-400">
          If you need further assistance, please email us at support@onse.com or call +1 (123) 456-7890.
        </p>
      </div>
    </main>
  )
}

