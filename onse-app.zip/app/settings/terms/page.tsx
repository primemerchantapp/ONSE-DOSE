"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"

export default function TermsPoliciesPage() {
  const router = useRouter()

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Terms & Policies</h1>
      </header>

      <div className="p-4 space-y-4">
        <h2 className="text-lg font-semibold">Terms of Service</h2>
        <p className="text-gray-400">
          By using the Onse app, you agree to our terms of service. These terms outline your rights and responsibilities
          as a user of our platform.
        </p>

        <h2 className="text-lg font-semibold mt-6">Privacy Policy</h2>
        <p className="text-gray-400">
          We take your privacy seriously. Our privacy policy explains how we collect, use, and protect your personal
          information.
        </p>

        <h2 className="text-lg font-semibold mt-6">Cookie Policy</h2>
        <p className="text-gray-400">
          We use cookies to enhance your experience on our platform. Our cookie policy provides details on how we use
          these technologies.
        </p>

        <p className="mt-6 text-sm text-gray-500">Last updated: June 1, 2023</p>
      </div>
    </main>
  )
}

