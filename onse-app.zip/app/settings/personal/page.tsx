"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function PersonalInformationPage() {
  const router = useRouter()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")

  const handleSave = () => {
    // Implement save functionality
    console.log("Saving personal information:", { name, email })
    router.back()
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="p-4 flex items-center sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <button onClick={() => router.back()} className="mr-4">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Personal Information</h1>
      </header>

      <div className="p-4 space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-1">
            Name
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-1">
            Email
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white"
          />
        </div>

        <Button onClick={handleSave} neon fullWidth className="mt-6">
          Save Changes
        </Button>
      </div>
    </main>
  )
}

