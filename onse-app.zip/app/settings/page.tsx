"use client"

import { useRouter } from "next/navigation"
import { BottomNav } from "@/components/bottom-nav"
import { Bell, HelpCircle, Lock, Moon, Shield, User, DollarSign } from "lucide-react"
import Link from "next/link"
import { useAuth } from "../providers"

export default function SettingsPage() {
  const router = useRouter()
  const { user } = useAuth()

  const settingsGroups = [
    {
      title: "Account",
      items: [
        { icon: User, label: "Personal Information", href: "/settings/personal" },
        { icon: Lock, label: "Security & Privacy", href: "/settings/security" },
      ],
    },
    {
      title: "Preferences",
      items: [
        { icon: Bell, label: "Notifications", href: "/settings/notifications" },
        { icon: Moon, label: "Appearance", href: "/settings/appearance" },
      ],
    },
    {
      title: "Support",
      items: [
        { icon: HelpCircle, label: "Help & Support", href: "/settings/help" },
        { icon: Shield, label: "Terms & Policies", href: "/settings/terms" },
      ],
    },
  ]

  const isAdmin = user?.email === "admin@onse.vip"

  return (
    <main className="min-h-screen bg-black text-white pb-20">
      <header className="p-4 sticky top-0 bg-black/80 backdrop-blur-sm z-10">
        <h1 className="text-2xl font-bold">Settings</h1>
      </header>

      <div className="p-4 space-y-6">
        {settingsGroups.map((group, groupIndex) => (
          <div key={groupIndex}>
            <h2 className="text-lg font-semibold mb-2">{group.title}</h2>
            <div className="bg-gray-900 rounded-xl overflow-hidden">
              {group.items.map((item, itemIndex) => (
                <Link
                  key={itemIndex}
                  href={item.href}
                  className="p-4 flex items-center justify-between border-b border-gray-800 last:border-b-0"
                >
                  <div className="flex items-center">
                    <item.icon size={20} className="mr-3 text-gray-400" />
                    <span>{item.label}</span>
                  </div>
                  <span className="text-gray-400">›</span>
                </Link>
              ))}
            </div>
          </div>
        ))}

        {isAdmin && (
          <div>
            <h2 className="text-lg font-semibold mb-2">Administration</h2>
            <div className="bg-gray-900 rounded-xl overflow-hidden">
              <Link href="/admin" className="p-4 flex items-center justify-between">
                <div className="flex items-center">
                  <DollarSign size={20} className="mr-3 text-neon-pink" />
                  <span>Admin Dashboard</span>
                </div>
                <span className="text-gray-400">›</span>
              </Link>
            </div>
          </div>
        )}

        <div className="text-center text-xs text-gray-500 pt-4">
          <p>Onse App v1.0.0</p>
          <p>© 2023 Onse Inc. All rights reserved.</p>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

