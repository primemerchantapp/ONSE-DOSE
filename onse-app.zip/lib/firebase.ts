import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { getAnalytics } from "firebase/analytics"

const firebaseConfig = {
  apiKey: "AIzaSyDtNedkJo6ikNneZZdrheiWbE3Dn2B8kwQ",
  authDomain: "ces-project-f8b4e.firebaseapp.com",
  databaseURL: "https://ces-project-f8b4e-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "ces-project-f8b4e",
  storageBucket: "ces-project-f8b4e.firebasestorage.app",
  messagingSenderId: "580767851656",
  appId: "1:580767851656:web:1355ddd848a0e8f3cdeb3d",
  measurementId: "G-N6G0YTEM6X",
}

const app = initializeApp(firebaseConfig)
const auth = getAuth(app)
const db = getFirestore(app)
const storage = getStorage(app)

let analytics = null
if (typeof window !== "undefined") {
  analytics = getAnalytics(app)
}

export { app, auth, db, storage, analytics }

export const initializeMessaging = async () => {
  if (typeof window !== "undefined") {
    try {
      const { getMessaging } = await import("firebase/messaging")
      return getMessaging(app)
    } catch (error) {
      console.error("Error initializing messaging:", error)
      return null
    }
  }
  return null
}

