import { doc, updateDoc, arrayUnion } from "firebase/firestore"
import { db } from "./firebase"

export const initializeNotifications = async (userId: string) => {
  if (typeof window === "undefined") return // Skip on server-side

  try {
    const { getToken, onMessage } = await import("firebase/messaging")
    const { initializeMessaging } = await import("./firebase")

    const messaging = initializeMessaging()
    if (!messaging) return

    const permission = await Notification.requestPermission()
    if (permission === "granted") {
      const token = await getToken(messaging, {
        vapidKey: "YOUR_VAPID_KEY_HERE", // Replace with your actual VAPID key
      })

      await updateDoc(doc(db, "users", userId), {
        fcmTokens: arrayUnion(token),
      })

      onMessage(messaging, (payload) => {
        console.log("Message received. ", payload)
        // You can handle the received message here, e.g., update UI or show a notification
      })
    }
  } catch (error) {
    console.error("Error initializing notifications:", error)
  }
}

export const sendNotification = async (userId: string, title: string, body: string, data?: any) => {
  try {
    const { setDoc } = await import("firebase/firestore")
    await setDoc(doc(db, "notifications", `${userId}_${Date.now()}`), {
      userId,
      title,
      body,
      data,
      timestamp: new Date(),
      read: false,
    })
    // In a real-world scenario, you would trigger a cloud function here to send the FCM message
  } catch (error) {
    console.error("Error sending notification:", error)
  }
}

