"use client"

import { useEffect, useRef, useState } from "react"
import { Volume2, VolumeX } from "lucide-react"

export function AudioPlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [showVolumeControl, setShowVolumeControl] = useState(true)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    const audio = new Audio(
      "https://firebasestorage.googleapis.com/v0/b/prime-h51r5w.appspot.com/o/onse%20(6).mp3?alt=media&token=6da5016f-c442-4a90-a629-5d1cd8316076",
    )
    audioRef.current = audio

    audio.addEventListener("play", () => setIsPlaying(true))
    audio.addEventListener("pause", () => setIsPlaying(false))

    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    const hideVolumeControl = () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
      timeoutRef.current = setTimeout(() => {
        setShowVolumeControl(false)
      }, 5000)
    }

    const handleUserActivity = () => {
      setShowVolumeControl(true)
      hideVolumeControl()
    }

    document.addEventListener("mousemove", handleUserActivity)
    document.addEventListener("touchstart", handleUserActivity)

    hideVolumeControl()

    return () => {
      document.removeEventListener("mousemove", handleUserActivity)
      document.removeEventListener("touchstart", handleUserActivity)
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        const playPromise = audioRef.current.play()
        if (playPromise !== undefined) {
          playPromise.catch((error) => {
            console.error("Audio playback failed:", error)
            setIsPlaying(false)
          })
        }
      }
    }
  }

  if (!showVolumeControl) return null

  return (
    <button
      onClick={togglePlayPause}
      className="fixed top-16 right-4 z-50 bg-gray-900 rounded-full p-2 shadow-lg"
      aria-label={isPlaying ? "Mute audio" : "Unmute audio"}
    >
      {isPlaying ? <Volume2 size={24} className="text-neon-pink" /> : <VolumeX size={24} className="text-gray-400" />}
    </button>
  )
}

