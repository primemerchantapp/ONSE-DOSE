interface OnseLogoProps {
  size?: number
  className?: string
}

export function OnseLogo({ size = 120, className = "" }: OnseLogoProps) {
  return (
    <div className={`relative ${className}`} style={{ width: size, height: size }}>
      <div
        className="absolute inset-0 rounded-full bg-gradient-to-r from-neon-pink to-neon-purple opacity-50"
        style={{ filter: "blur(20px)" }}
      />
      <div className="absolute inset-0 rounded-full border border-white/20" />
      <div className="absolute inset-0 flex items-center justify-center">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tinder2-x6qHLvkvpqwn1OJ3XZVnScHra3D8OY.png"
          alt="ONSE Logo"
          className="w-4/5 h-4/5 object-contain"
        />
      </div>
    </div>
  )
}

