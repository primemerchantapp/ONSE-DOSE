"use client"

import { useRouter, usePathname } from "next/navigation"
import { Bell, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/app/providers"
import { useEffect, useState } from "react"
import { collection, query, where, onSnapshot } from "firebase/firestore"
import { db } from "@/lib/firebase"
import Image from "next/image"

interface AppHeaderProps {
  title?: string
  showBackButton?: boolean
  showProfile?: boolean
}

export function AppHeader({ title, showBackButton = false, showProfile = false }: AppHeaderProps) {
  const router = useRouter()
  const pathname = usePathname()
  const { user, profile } = useAuth()
  const [unreadNotifications, setUnreadNotifications] = useState(0)

  useEffect(() => {
    if (!user) return

    const q = query(collection(db, "notifications"), where("userId", "==", user.uid), where("read", "==", false))

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setUnreadNotifications(snapshot.size)
    })

    return () => unsubscribe()
  }, [user])

  return (
    <header className="p-4 flex items-center justify-between sticky top-0 bg-black/80 backdrop-blur-sm z-10 border-b border-gray-800">
      <div className="flex items-center">
        {showBackButton && (
          <button onClick={() => router.back()} className="mr-4">
            <ArrowLeft size={24} />
          </button>
        )}
        {pathname === "/dashboard" ? (
          <h1 className="text-2xl font-bold neon-text">ONSE</h1>
        ) : (
          <h1 className="text-xl font-bold">{title}</h1>
        )}
      </div>

      <div className="flex items-center space-x-4">
        <Link href="/notifications" className="relative">
          <Bell size={24} className="text-white" />
          {unreadNotifications > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              {unreadNotifications}
            </span>
          )}
        </Link>

        {showProfile && (
          <Link href="/profile">
            <div className="w-10 h-10 rounded-full bg-gray-800 overflow-hidden">
              {profile?.photos && profile.photos[0] ? (
                <Image
                  src={profile.photos[0] || "/placeholder.svg"}
                  alt="Profile"
                  width={40}
                  height={40}
                  className="object-cover w-full h-full"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400">
                  {profile?.name?.[0] || user?.email?.[0] || "U"}
                </div>
              )}
            </div>
          </Link>
        )}
      </div>
    </header>
  )
}

