"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export function InstallPrompt() {
  const [showPrompt, setShowPrompt] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)

  useEffect(() => {
    // Check if the app is already installed
    if (window.matchMedia("(display-mode: standalone)").matches) {
      return // App is already installed
    }

    // Store the install prompt event
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setShowPrompt(true)
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

    // Check if the user has previously dismissed the prompt
    const hasPromptBeenDismissed = localStorage.getItem("installPromptDismissed")
    if (hasPromptBeenDismissed) {
      setShowPrompt(false)
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    }
  }, [])

  const handleInstallClick = () => {
    if (!deferredPrompt) return

    // Show the install prompt
    deferredPrompt.prompt()

    // Wait for the user to respond to the prompt
    deferredPrompt.userChoice.then((choiceResult: { outcome: string }) => {
      if (choiceResult.outcome === "accepted") {
        console.log("User accepted the install prompt")
      } else {
        console.log("User dismissed the install prompt")
      }
      setDeferredPrompt(null)
      setShowPrompt(false)
    })
  }

  const dismissPrompt = () => {
    setShowPrompt(false)
    localStorage.setItem("installPromptDismissed", "true")
  }

  if (!showPrompt) return null

  return (
    <div className="fixed bottom-20 left-4 right-4 bg-gray-900 rounded-xl p-4 shadow-lg z-50 border border-gray-800">
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-bold text-white">Install Onse App</h3>
        <button onClick={dismissPrompt} className="text-gray-400">
          <X size={20} />
        </button>
      </div>
      <p className="text-gray-300 text-sm mb-3">
        Install Onse on your device for a better experience and quick access.
      </p>
      <Button neon onClick={handleInstallClick} className="w-full">
        Install Now
      </Button>
    </div>
  )
}

