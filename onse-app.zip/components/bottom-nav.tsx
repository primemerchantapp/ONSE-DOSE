"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, MessageSquare, Calendar, User, DollarSign } from "lucide-react"

export function BottomNav() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path
  }

  const navItems = [
    { href: "/dashboard", icon: Home, label: "Home" },
    { href: "/bookings", icon: Calendar, label: "Bookings" },
    { href: "/credits", icon: DollarSign, label: "Credits" },
    { href: "/messages", icon: MessageSquare, label: "Messages" },
    { href: "/profile", icon: User, label: "Profile" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 z-50">
      <div className="flex justify-around py-3">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center ${isActive(item.href) ? "text-neon-pink" : "text-gray-500"}`}
          >
            <item.icon size={24} className={isActive(item.href) ? "text-neon-pink" : ""} />
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  )
}

